import express from "express";
import mysql2 from "mysql2";
import cors from "cors";
import multer from "multer";
import path from "path";
import bodyParser from "body-parser";
import { fileURLToPath } from "url";
import bcrypt from "bcrypt"
const app = express();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const db = mysql2.createConnection({
  host: "localhost",
  user: "root",
  password: "Aditya@02",
  database: "matromonial",
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

var imgconfig = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, "./uploads");
  },
  filename: (req, file, callback) => {
    // Extracting original filename
    const originalName = file.originalname;

    callback(null, originalName);
  },
});

// img filter
const isImage = (req, file, callback) => {
  if (file.mimetype.startsWith("image")) {
    callback(null, true);
  } else {
    callback(null, Error("only image is allowed"));
  }
};

var upload = multer({
  storage: imgconfig,
  fileFilter: isImage,
});

app.post("/signup", (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password)
    return res.json({
      status: "error",
      error: "Please Enter your email and password",
    });
  else {
    db.query(
      "SELECT email from register1 where email=?",
      [email],
      async (err, result) => {
        if (err) throw err;
        if (result[0])
          return res.json({
            status: "error",
            error: "Email has already been registered",
          });
        else {
          db.query(
            "Insert into register1 set ?",
            { name: name, email: email, password: password },
            (error, result) => {
              if (error) throw error;
              return res.json({
                status: "success",
                success: "User has been registered",
              });
            }
          );
        }
      }
    );
  }
});

app.post("/login", (req, res) => {
  const sql = "SELECT * FROM register1 WHERE email = ?";
  db.query(sql, [req.body.email], (err, result) => {
    if (err) return res.json({ Message: "Error inside server" });

    if (result.length > 0) {
      // Assuming the password is encrypted using some method like bcrypt
      // You should replace the encryption method and parameters with your actual implementation
      bcrypt.compare(req.body.password, result[0].password, (bcryptErr, bcryptRes) => {
        if (bcryptErr) {
          return res.json({ Message: "Error comparing passwords" });
        }
        if (bcryptRes) {
          return res.json({ Login: true });
        } else {
          return res.json({ Login: false });
        }
      });
    } else {
      return res.json({ Login: false });
    }
  });
});

app.post("/contact", cors(), async (req, res) => {
  const sql = "INSERT INTO contact (`name` , `email` ,`massage` ) VALUES (?)";

  const Values = [req.body.name, req.body.email, req.body.massage];
  db.query(sql, [Values], (err, result) => {
    console.log("Error  ", err);
    if (err) return res.json({ Message: "Error in Node" }, err);
    return res.json(result);
  });
});

app.post("/enroll", async (req, res) => {
  const sql =
    "INSERT INTO info (`fullname` , `email` ,`phnumber` , `address` ,`pin`,`complexion` ,`date` ,`height`,`pydisability`,`subcast`,`bloodgroup`, `maritalstatus`, `diet`,`lens`,`spectacle`,`disability`,gender ) VALUES (?)";

  const Values = [
    req.body.fullname,
    req.body.email,
    req.body.phnumber,
    req.body.address,
    req.body.pin,
    req.body.complexion,
    req.body.date,
    req.body.height,
    req.body.pydisability,
    req.body.subcast,
    req.body.bloodgroup,
    req.body.maritalstatus,
    req.body.diet,
    req.body.lens,
    req.body.spectacle,
    req.body.disability,
    req.body.gender,
  ];
  db.query(sql, [Values], (err, result) => {
    console.log("Error  ", err);
    if (err) return res.json({ Message: "Error in Node" }, err);
    return res.json(result);
  });
});

app.post("/enroll1", cors(), async (req, res) => {
  const sql =
    "INSERT INTO info2 (`rashi` , `nakshatra` ,`charan` , `nadi` ,`gan`,`mangal` ,`educationarea` ,`education`,`occupationtype`,`occupationdetails`,`income`, `workingcity`, `ifmore`,`pan`,`residence`,`email1`,`email2`,`mobile1`,`mobile2`,`phone1`,`phone2` ) VALUES (?)";

  const Values = [
    req.body.rashi,
    req.body.nakshatra,
    req.body.charan,
    req.body.nadi,
    req.body.gan,
    req.body.mangal,
    req.body.educationarea,
    req.body.education,
    req.body.occupationtype,
    req.body.occupationdetails,
    req.body.income,
    req.body.workingcity,
    req.body.ifmore,
    req.body.pan,
    req.body.residence,
    req.body.email1,
    req.body.email2,
    req.body.mobile1,
    req.body.mobile2,
    req.body.phone1,
    req.body.phone2,
  ];
  db.query(sql, [Values], (err, result) => {
    console.log("Error  ", err);
    if (err) return res.json({ Message: "Error in Node" }, err);
    return res.json(result);
  });
});

app.post(
  "/enroll2",
  upload.fields([{ name: "first_photo" }, { name: "second_photo" }]),
  async (req, res) => {
    // Check if files are uploaded
    if (!req.files || !req.files["first_photo"] || !req.files["second_photo"]) {
      return res.status(400).json({ Message: "Both photos are required" });
    }

    const sql =
      "INSERT INTO info3 (`father`, `mother`, `brother`, `sister`, `married_brother`, `married_sister`, `fathername`, `mothername`, `fatheroccupation`, `motheroccupation`, `first_photo`, `second_photo`, `email`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    const Values = [
      req.body.father,
      req.body.mother,
      req.body.brother,
      req.body.sister,
      req.body.married_brother,
      req.body.married_sister,
      req.body.fathername,
      req.body.mothername,
      req.body.fatheroccupation,
      req.body.motheroccupation,
      req.files["first_photo"][0].originalname,
      req.files["second_photo"][0].originalname,
      req.body.email,
    ];

    db.query(sql, Values, (err, result) => {
      if (err) {
        console.error("Error: ", err);
        return res.status(500).json({ Message: "Error in Node" });
      }
      return res.json(result);
    });
  }
);

app.get("/singleuser", function (req, res) {
  const sql =
    "SELECT t1.*, t2.*, t3.* FROM info t1 INNER JOIN info2 t2 ON t1.email = t2.email1 INNER JOIN info3 t3 ON t2.email1 = t3.email; ";
  db.query(sql, function (err, result) {
    if (err) {
      console.log(err);
      res.status(500).send("Internal Server Error");
      return;
    }
    res.json(result);
  });
});

app.get("/userdata", function (req, res) {
  const email = req.query.email;
  if (!email) {
    return res.status(400).json({ error: "Email query parameter is required" });
  }

  const sql = "SELECT * FROM info WHERE email = ?";
  db.query(sql, [email], function (err, result) {
    if (err) {
      console.log(err);
      return res
        .status(500)
        .json({ error: "An error occurred while fetching data" });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: "No user found with this email" });
    }
    res.json(result);
  });
});

app.get("/userdata1", function (req, res) {
  const email = req.query.email;
  if (!email) {
    return res.status(400).json({ error: "Email query parameter is required" });
  }

  const sql = "SELECT * FROM info2 WHERE email1 = ?";
  db.query(sql, [email], function (err, result) {
    if (err) {
      console.log(err);
      return res
        .status(500)
        .json({ error: "An error occurred while fetching data" });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: "No user found with this email" });
    }
    res.json(result);
  });
});

app.get("/userdata3", function (req, res) {
  const email = req.query.email;
  if (!email) {
    return res.status(400).json({ error: "Email query parameter is required" });
  }

  const sql = "SELECT * FROM info3 WHERE email = ?";
  db.query(sql, [email], function (err, result) {
    if (err) {
      console.log(err);
      return res
        .status(500)
        .json({ error: "An error occurred while fetching data" });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: "No user found with this email" });
    }
    res.json(result);
  });
});
app.post("/success", upload.single("file"), (req, res) => {
  const { name, sname, location, slocation, description } = req.body;
  const file = req.file ? req.file.filename : null;

  if (!name || !sname || !location || !slocation || !description || !file) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const sql =
    "INSERT INTO successstory (name, spoucename, location, location2, description, photo) VALUES (?, ?, ?, ?, ?, ?)";
  db.query(
    sql,
    [name, sname, location, slocation, description, file],
    (err, result) => {
      if (err) throw err;
      res.json({ message: "Data submitted successfully", id: result.insertId });
    }
  );
});

app.get("/success", function (req, res) {
  const sql = "SELECT * FROM successstory;";
  db.query(sql, function (err, results) {
    if (err) {
      console.log(err);
      res.status(500).send("Internal Server Error");
      return;
    }
    res.json(results);
  });
});

app.put("/userdata", (req, res) => {
  const { email, data } = req.body;
  if (!email || !data) {
    return res.status(400).json({ error: "Email and data are required" });
  }

  const sql = `UPDATE info SET fullname=?, phnumber=?, address=?, pin=?, complexion=?, date=?, height=?, pydisability=?, subcast=?, bloodgroup=?, maritalstatus=?, diet=?, lens=?, spectacle=?, disability=?, gender=? WHERE email=?`;
  const values = [
    data.fullname,
    data.phnumber,
    data.address,
    data.pin,
    data.complexion,
    data.date,
    data.height,
    data.pydisability,
    data.subcast,
    data.bloodgroup,
    data.maritalstatus,
    data.diet,
    data.lens,
    data.spectacle,
    data.disability,
    data.gender,
    email,
  ];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error(err);
      return res
        .status(500)
        .json({ error: "An error occurred while updating the user data" });
    }
    return res.json({
      success: true,
      message: "User data updated successfully",
      result,
    });
  });
});

app.put("/userdata1", (req, res) => {
  const { email, data } = req.body;
  if (!email || !data) {
    return res.status(400).json({ error: "Email and data are required" });
  }

  const sql = `UPDATE info2 SET rashi=?, nakshatra=?, charan=?, nadi=?, gan=?, mangal=?, educationarea=?, education=?, occupationtype=?, occupationdetails=?, income=?, workingcity=?, ifmore=?, pan=?, residence=?, email1=?, email2=?, mobile1=?, mobile2=?, phone1=?, phone2=? WHERE email1=?`;
  const values = [
    data.rashi,
    data.nakshatra,
    data.charan,
    data.nadi,
    data.gan,
    data.mangal,
    data.educationarea,
    data.education,
    data.occupationtype,
    data.occupationdetails,
    data.income,
    data.workingcity,
    data.ifmore,
    data.pan,
    data.residence,
    data.email1,
    data.email2,
    data.mobile1,
    data.mobile2,
    data.phone1,
    data.phone2,
    email,
  ];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error(err);
      return res
        .status(500)
        .json({ error: "An error occurred while updating the user data" });
    }
    return res.json({
      success: true,
      message: "User data updated successfully",
      result,
    });
  });
});

app.put("/userdata3", (req, res) => {
  const { email, data } = req.body;
  if (!email || !data) {
    return res.status(400).json({ error: "Email and data are required" });
  }

  const sql = `UPDATE info3 SET father=?, mother=?, brother=?, sister=?, married_brother=?, married_sister=?, fathername=?, mothername=?, fatheroccupation=?, motheroccupation=?, first_photo=?, second_photo=? WHERE email=?`;
  const values = [
    data.father,
    data.mother,
    data.brother,
    data.sister,
    data.married_brother,
    data.married_sister,
    data.fathername,
    data.mothername,
    data.fatheroccupation,
    data.motheroccupation,
    data.first_photo,
    data.second_photo,
    email,
  ];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error(err);
      return res
        .status(500)
        .json({ error: "An error occurred while updating the user data" });
    }
    return res.json({
      success: true,
      message: "User data updated successfully",
      result,
    });
  });
});
app.listen(5000, () => {
  console.log("Connected to the server");
});



app.post("/notify/:email", async (req, res) => {
  const userEmail = req.params.email;
  // Here you can implement the logic to send a notification to the user's dashboard
  // You can use any method like sending an email, push notification, or updating a flag in the database
  // For simplicity, let's assume you just console log the email address
  console.log(`Notification sent to ${userEmail}`);
  res.sendStatus(200); // Send a success response
});