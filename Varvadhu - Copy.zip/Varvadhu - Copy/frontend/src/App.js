import "./App.css";
import "@fontsource/roboto/300.css";
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/500.css";
import "@fontsource/roboto/700.css";

import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Provider } from "react-redux";
import store from "./Store";
import RegisterForm1 from "./Components/Register/RegisterForm1";
import RegisterForm2 from "./Components/Register/RegisterForm2";
import About from "./Components/Pages/About";
import Contact from "./Components/Pages/Contact";
import SucessStories from "./Components/Pages/SucessStories";
import Enroll from "./Components/Register/Enroll";
import Rules from "./Components/Pages/Rules";
import Profiles from "./Components/Pages/Profiles";
import HomePage from "./Components/Pages/HomePage";
import MyProfile from "./Components/Pages/MyProfile";

import Dashboard from "./Components/Admin/Dashboard";
import NavBar from "./Components/Navbar";
import MemberForm from "./Components/Pages/MemberForm";
import EditMyProfile from "./Components/Pages/EditMyProfile";

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <NavBar />
        <Routes>
          {/* isAuthenticated={isAuthenticated} */}
          <Route path="*" element={<HomePage isAuthenticated={false} />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />

          <Route path="/successstories" element={<SucessStories />} />
          <Route path="/register" element={<Enroll />} />
          <Route path="/rules" element={<Rules />} />
          <Route path="/form1" element={<RegisterForm1 />} />
          <Route path="/form2" element={<RegisterForm2 />} />
          <Route path="/dashboard/*" element={<Dashboard />} />
          <Route path="/profiles" element={<Profiles isAuthenticated={false} />}/>
          <Route path="/membership"element={<MemberForm />}/>
          <Route path="/myprofile" element={<MyProfile />} />
          <Route path="/editmyprofile" element={<EditMyProfile />} />
        </Routes>
      </BrowserRouter>

    </Provider>
  );
}

export default App;
