// actions/authActions.js
import { LOGIN, LOGIN_FAILURE, LOGOUT } from './Types';

export const Login = (user) => {
  return {
    type: LOGIN,
    payload: user
  };
};


export const LoginFailure = () => {
  return {
    type: LOGIN_FAILURE
  };
};

export const LogoutUser = () => {
  return {
    type: LOGOUT
  };
};
