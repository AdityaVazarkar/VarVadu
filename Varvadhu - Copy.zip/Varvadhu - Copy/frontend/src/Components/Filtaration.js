import React, { useState } from 'react';
import { TextField, Box, MenuItem, Typography, Container, Button } from '@mui/material';

const ageOptions = Array.from({ length: 83 }, (_, i) => i + 18);
const genderOptions = [
  { label: "Any", value: "" },
  { label: "Male", value: "Male" },
  { label: "Female", value: "female" }
];

const Filtaration = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [fromAge, setFromAge] = useState('');
  const [toAge, setToAge] = useState('');
  const [gender, setGender] = useState('');

  const handleSearchTermChange = (event) => {
    const value = event.target.value;
    setSearchTerm(value);
    onSearch({ searchTerm: value, fromAge, toAge, gender });
  };

  const handleFromAgeChange = (event) => {
    const value = event.target.value;
    setFromAge(value);
    onSearch({ searchTerm, fromAge: value, toAge, gender });
  };

  const handleToAgeChange = (event) => {
    const value = event.target.value;
    setToAge(value);
    onSearch({ searchTerm, fromAge, toAge: value, gender });
  };

  const handleGenderChange = (event) => {
    const value = event.target.value;
    setGender(value);
    onSearch({ searchTerm, fromAge, toAge, gender: value });
  };

  const handleClear = () => {
    setSearchTerm('');
    setFromAge('');
    setToAge('');
    setGender('');
    onSearch({ searchTerm: '', fromAge: '', toAge: '', gender: '' });
  };

  return (
    <Container className="border-2 border-slate-900 bg-slate-100 p-10 rounded-2xl">
    <Box sx={{ marginBottom: '20px', textAlign: 'center' }}>
      <TextField
        label="Search profiles..."
        variant="outlined"
        value={searchTerm}
        onChange={handleSearchTermChange}
        fullWidth
        sx={{ marginBottom: 2 }}
      />
      <Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
        <TextField
          select
          label="From Age"
          value={fromAge}
          onChange={handleFromAgeChange}
          sx={{ width: '30%' }}
        >
          {ageOptions.map((age) => (
            <MenuItem key={age} value={age}>
              {age}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          select
          label="To Age"
          value={toAge}
          onChange={handleToAgeChange}
          sx={{ width: '30%' }}
        >
          {ageOptions.map((age) => (
            <MenuItem key={age} value={age}>
              {age}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          select
          label="Gender"
          value={gender}
          onChange={handleGenderChange}
          sx={{ width: '30%' }}
        >
          {genderOptions.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        </Box>

      </Box>
      <Box sx={{display:"flex",justifyContent:"center"}}>

      <Button variant="contained" color="secondary" onClick={handleClear}>
        Clear
      </Button>
      </Box>
    
      </Container>
  );
};

export default Filtaration;
