import React from "react";
import MemberShipCard from "./MemberShipCard";
import { Box, Container, Typography } from "@mui/material";


const MemberShip = () => {
  return (

      <Container>
      <Typography sx={{ textAlign: "center", paddingTop: "10vh" }} variant="h4">
        MemberShip options
      </Typography>
      <Box
        sx={{ display: 'ruby', alignItems: "center", justifyContent: "center" }}
      >
        <MemberShipCard
          image={"./gold-member-club-card.jpg"}
          amount={60000}
          membershipType="Gold"
          expiration="2024-12-31"
        />
        <MemberShipCard
          image={"./platinum_membership.jpg"}
          membershipType="siver"
          amount = {50000}
          expiration="2024-12-31"
        />
        <MemberShipCard
          image={"./silver_member.jpg"}
          amount = {50000}
          membershipType="platinum"
          expiration="2024-12-31"
        />
        <MemberShipCard
          image={"./silver_member.jpg"}
          amount = {50000}
          membershipType="platinum"
          expiration="2024-12-31"
        />
        </Box>
      </Container>
  );
};

export default MemberShip;
