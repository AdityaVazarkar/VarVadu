import React, { useState , useRef  } from "react";
import axios from "axios";
import emailjs from "@emailjs/browser";
import {
  Container,
  Grid,
  Typography,
  TextField,
  Button,
  Divider,
  Card,
  CardContent,
} from "@mui/material";
import { ToastContainer, toast } from "react-toastify";

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [massage, setmassage] = useState("");

  const form = useRef();

  const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .sendForm("service_ad25mqd", "template_az1pzye", form.current, {
        publicKey: "O8ji8Z6wRrhB26FZS",
      })
      .then(
        () => {
          console.log("SUCCESS!");
          alert("SUCCESSFULL SEND");
        },
        (error) => {
          console.log("FAILED...", error.text);
          alert("FAILED TO SEND");
        }
      );
  };


  return (
    <Container maxWidth="lg">
<ToastContainer />
      <Typography
        variant="h4"
        component="h1"
        align="center"
        gutterBottom
        sx={{ marginTop: "30px" }}
      >
        Contact Us
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Typography variant="body1" gutterBottom sx={{ textAlign: "center" }}>
            Have a question or want to get in touch? Please fill out the form
            below and we'll get back to you as soon as possible.
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <form  ref={form}
              onSubmit={sendEmail}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  required
                  id="name"
              
                  name="user_name"
                  label="Your Name"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  required
                  id="email"
                  name="user_email"
             
                 
                  label="Your Email"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  required
                  id="massage"
                  name="message"
                  label="massage"
                
           
                  multiline
                  rows={4}
                />
              </Grid>
              <Grid item xs={12}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  fullWidth
                >
                  Send massage
                </Button>
              </Grid>
            </Grid>
          </form>
        </Grid>
        <Divider />
        <Grid item xs={12} sx={{ marginTop: "10vh", padding: "5vh" }}>
          <Card elevation={3}>
            <CardContent>
              <Typography
                variant="h4"
                className="center"
                gutterBottom
                sx={{ textAlign: "center" }}
              >
                Contact Details
              </Typography>
              <Typography variant="h6" sx={{ width: "auto" }}>
                Owner:
              </Typography>
              <Typography variant="body1" sx={{ textAlign: "center" }}>
                Name of the Owner
              </Typography>
              <Typography variant="h6" sx={{ width: "auto" }}>
                Address:
              </Typography>
              <Typography variant="body1" sx={{ textAlign: "center" }}>
                123 Main Street, City, Country
              </Typography>
              <Typography variant="h6">Phone:</Typography>
              <Typography variant="body1" sx={{ textAlign: "center" }}>
                +1234567890
              </Typography>
              <Typography variant="h6">Email:</Typography>
              <Typography variant="body1" sx={{ textAlign: "center" }}>
                info@example.com
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Typography variant="h4" sx={{ textAlign: "center" }}>
        Map
      </Typography>
      <Container sx={{ width: "100%", height: "400px", padding: "20px" }}>
        <iframe
          title="Google Map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3818.5039197912756!2d74.5714980752113!3d16.850948818037168!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc1186617b3af31%3A0x2b08432599d57665!2s4th%20Ln%20%26%20Civil%20Hospital%20Rd%2C%20South%20Shivaji%20Nagar%2C%20Patrakar%20Nagar%2C%20Sangli%20Miraj%20Kupwad%2C%20Sangli%2C%20Maharashtra%20416416!5e0!3m2!1sen!2sin!4v1710839660285!5m2!1sen!2sin"
          width="100%"
          height="100%"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </Container>
    </Container>
  );
}
