import * as React from "react";
// import Avatar from '@mui/material/Avatar';
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Carousel from "../Carsoul";
import { NavLink } from "react-router-dom";
import MemberShip from "../MemberShip";
import { makeStyles } from "@mui/styles";
import Filtaration from "../Filtaration";
import HomeProfile from "./HomeProfile";
import About from "./About";
import { useSelector } from "react-redux";

const defaultTheme = createTheme();

// Define custom styles using makeStyles
const useStyles = makeStyles({
  fixedWidthImage: {
    // width: '1550px', // Set the desired fixed width for the image
    // height: '630px', // Set the desired height for the image
    marginTop: -11, // Set the desired margin
    zIndex: 1,
    // backgroundPosition: 'center center',
    backgroundRepeat: "no-repeat",
    backgroundAttachment: "initial",
    backgroundOrigin: "initial",
    backgroundClip: "initial",
    backgroundColor: "initial",
    backgroundSize: "cover !important",
  },
});

export default function Home() {
  const classes = useStyles();
  React.useEffect(() => {
    const getuser = () => {
    };
    getuser();
  }, []);

  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  return (
    <ThemeProvider theme={defaultTheme}>
      <CssBaseline />
      {/* <StepImages /> */}

      <Grid container component="main">
        <img
          src="./home-banner.jpeg"
          style={{ marginTop: 11, zIndex: 1 }}
          className={classes.fixedWidthImage}
          alt="VarVadu"
        />

      </Grid>

      <Box>
        <Carousel />
      </Box>

      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "20px",
        }}
      >
        <Button
          variant="contained"
          component={NavLink}
          to="/successstories"
          sx={{ color: "white", textAlign: "center" }}
        >
          See More Success Stories
        </Button>
      </Box>

      {isAuthenticated ? (
        <>
          <HomeProfile />
          <Box sx={{ display: "block", textAlign: "center" }}>
            <Button
              variant="contained"
              component={NavLink}
              to="/profiles"
              sx={{ color: "white", textAlign: "center", marginTop: "20px" }}
            >
              See More Profiles
            </Button>
          </Box>
        </>
      ) : (
        <Typography variant="body1" align="center">
          Login please to see profiles
        </Typography>
      )}

      <MemberShip />
      <About />
    </ThemeProvider>
  );
}