import { Box, Container, Typography } from "@mui/material";
import ProfileCard from "../ProfileCard";
import { useEffect, useState } from "react";
import axios from 'axios';

const HomeProfile = () => {

  function calculateAge(dateOfBirth) {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/singleuser")
      .then((res) => {
        const usersData = res.data.map((user) => ({
          ...user,
          age: calculateAge(user.date),
        }));
        setUsers(usersData);

      })
      .catch((err) => console.log(err));
  }, []);


 

  return (
    <Container>
      <Typography sx={{ textAlign: "center", paddingTop: "10vh" }} variant="h4">
        Profile
      </Typography>
      <Box sx={{ display: "flex", flexWrap: "wrap" }}>
        {users.slice(0,3).map((user, index) => (
          <ProfileCard
            image={`http://localhost:5000/uploads/${user.first_photo}`}
            key={user.id}
            name={user.fullname}
            age={user.age}
            occupationdetails={user.occupationdetails}
            workingcity={user.address}
            height={user.height}
            subcast={user.subcast}
            lens={user.lens}
            rashi={user.rashi}
            occupationtype={user.occupationtype}
            income={user.income}
            mobile1={user.mobile1}
          />
        ))}
      </Box>
    </Container>
  );
};

export default HomeProfile;
