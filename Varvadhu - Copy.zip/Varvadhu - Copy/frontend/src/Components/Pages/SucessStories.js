import React, { useEffect, useState } from 'react';
import Cards from '../Cards';
import { Box, Typography } from '@mui/material';
import axios from 'axios';

const SucessStories = () => {
  const [stories, setStories] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get('http://localhost:5000/success');
        setStories(res.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <Typography sx={{ textAlign: 'center', paddingTop: '10vh' }} variant='h4'> Our Success Stories</Typography>
      
      <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap' }}>
        {stories.map((story, index) => (
          <Cards
            key={index}
            image={`http://localhost:5000/uploads/${story.photo}`}
            name={story.name}
            sname={story.spoucename}
            location={story.location}
            slocation={story.location2}
            description={story.description}
          />
        ))}
      </Box>
    </>
  );
};

export default SucessStories;
