import React from 'react';
import { Container, Typography, Divider, Box } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { Link } from 'react-router-dom';

const useStyles = makeStyles({
  listItem: {
    margin: 5,
  },
  heading: {
    fontWeight: 'bold',
      margin: 5,
    padding: 10,
  },
  block: {
    listStyleType: 'none',
    display:'inline',
    padding: 0,
    margin: 0,
  },
  '@media (max-width: 600px)': {
    heading: {
      fontSize: '1.5rem',
    },
    block: {
      textAlign: 'center',
    },
  },
});

const About = () => {
  const classes = useStyles();

  return (
    <>
        <Typography variant="h4" gutterBottom sx={{textAlign:'center', margin:6}}>
          About varvadhu
      </Typography>
      

      <Container maxWidth="md" sx={{ mt: 4 }}>
      <img src='./about.jpg' style={{height:190, margin:'auto'}} alt=''/>
        <Divider sx={{ mb: 2 }} />
        <Typography variant="body1" paragraph>
          VarVadhuis a registered and trademarked corporation based in India. We are a leading international matchmaking company for singles globally. Through our network, we want to make the process of the relationship journey relatively effortless. All profiles are checked manually with phone verification to ensure a safe environment for the users.
        </Typography>
        <Typography variant="body1" paragraph>
          Our mission is to connect people from all walks of life and cultures in meaningful relationships. Whether you're looking for a lifelong commitment, companionship, or friendship, varvadhuprovides a safe and secure environment to explore your options.
        </Typography>
        <Typography variant="body1" paragraph>
          At varvadhu, we understand the importance of privacy and security. We employ stringent measures to safeguard your personal information and ensure a positive experience for all our users.
        </Typography>
        <Typography variant="body1" paragraph>
          Join varvadhu today and take the first step towards finding your perfect match!
        </Typography>
      </Container>

      <Box sx={{ display: 'flex', position:'relative' , backgroundColor: '#d4d2d2', justifyContent: 'space-evenly', bottom:0}}>
        <Box>
          <Typography variant="h6" className={classes.heading}>Need Help</Typography>
          <ul className={classes.block}>
            <Link to="/register" className={classes.listItem}>Member Login</Link>
            <Link to="/register" className={classes.listItem}>Sign up</Link>
            <Link className={classes.listItem} to="/register">Member Support</Link>
          </ul>
        </Box>
        <Box>
          <Typography variant="h6" className={classes.heading}>Company</Typography>
          <ul className={classes.block}>
            <Link to="/about">About Us</Link>
            <Link to="/rules"li>Rules</Link>
            <Link to="/register">Submit Story</Link>
          </ul>
        </Box>
        <Box>
          <Typography variant="h6" className={classes.heading}>More</Typography>
          <ul className={classes.block}>
            <Link to="/enroll">Top Ranking Cities</Link>
            <Link to="/contact">Map</Link>
          </ul>
        </Box>
      </Box>
    </>
  );
};

export default About;
