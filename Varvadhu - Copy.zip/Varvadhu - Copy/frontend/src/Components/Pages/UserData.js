import React,{ useEffect, useState } from "react";
import { Link } from "react-router-dom";
const UserData = () => {
    const [userData, setUserdata]= useState([]); 
    useEffect( ()=>{
        const getUserdata= async()=>{
            const reqData= await fetch("http://localhost:5000/userData");
            const resData= await reqData.json();
            setUserdata(resData);
           // console.log(resData);
        }
        getUserdata();
    },[]);
    const [userData1, setUserdata1]= useState([]); 
    useEffect( ()=>{
        const getUserdata= async()=>{
            const reqData= await fetch("http://localhost:5000/userData1");
            const resData= await reqData.json();
            setUserdata1(resData);
           // console.log(resData);
        }
        getUserdata();
    },[]);
  return (
    <React.Fragment>
    <div className="container">
        <div className="row">
            <div className="col-md-12">
            <h5 className="mt-2">User Data</h5>
               <div className="d-grid d-md-flex justify-content-md-end mb-3">
                {/* <Link to="/adduser" className="btn btn-warning">Add New User</Link> */}
               </div>
               <table className="table table-bordered table-striped">
                <thead>
                <tr>
                <th>Sr. No</th>
                <th>Full Name</th>
                <th>email</th>
                <th>Phone No</th>
                <th>Address</th>
                <th>Pin</th>
                </tr>
                </thead>
                <tbody>
                 { userData.map ( (userData, index)=>(                           
                <tr key={index}>
                <td>{index+1} </td>
                <td>{ userData.fullname } </td>
                <td>{ userData.email } </td>
                <td>{ userData.phnumber } </td>
                <td>{ userData.address } </td>
                <td>{ userData.pin } </td>
                <td>
                 <Link to={"/editUser/"+userData.userid} className="btn btn-success mx-2">Edit</Link>
                 <Link to="/deleteUser" className="btn btn-danger">Delete</Link>
                
                </td>
                </tr>
                )) 
                }                 
                </tbody>
                <thead>
                    <tr>
                        <tr>Photo</tr>
                    </tr>
                </thead>
                <tbody>
                {userData1.map((userData1 ,index)=>(
                    <tr >
                        <td>
                            <img src= {userData1.first_photo} alt="" />
                        </td>
                    </tr>
                 ))}       
                </tbody>
                </table>                            
            </div>
        </div>
    </div>
    
</React.Fragment>
  );
};

export default UserData;
