import React, { useEffect, useState } from "react";
import axios from "axios";
import Typography from "@mui/material/Typography";
import { Avatar, Container, Box, CardMedia, TextField, Button } from "@mui/material";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";

export default function EditMyProfile() {
  const [userData, setUserData] = useState(null);
  const [userData1, setUserData1] = useState(null);
  const [userData2, setUserData2] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({});

  const navigate = useNavigate();
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userEmail = sessionStorage.getItem("user");

        if (!userEmail) {
          console.error("No user email found in sessionStorage");
          return;
        }

        const response = await axios.get(
          `http://localhost:5000/userdata?email=${userEmail}`
        );
        const response1 = await axios.get(
          `http://localhost:5000/userdata1?email=${userEmail}`
        );
        const response2 = await axios.get(
          `http://localhost:5000/userdata3?email=${userEmail}`
        );

        setUserData(response.data[0]);
        setUserData1(response1.data[0]);
        setUserData2(response2.data[0]);
        setFormData({
          ...response.data[0],
          ...response1.data[0],
          ...response2.data[0]
        });
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async () => {
    try {
      await axios.put('http://localhost:5000/userdata', {
        email: userData.email,
        data: formData,
      });
        
      await axios.put('http://localhost:5000/userdata1', {
        email: userData1.email,
        data: formData,
      });
      await axios.put('http://localhost:5000/userdata3', {
        email: userData2.email,
        data: formData,
      });
  
      toast.success('Profile updated successfully');
      setEditMode(false);
    } catch (error) {
      toast.success(' updating profile');
      console.log(' updating profile',);
      }
      
      navigate("/dashboard/MyProfile")
  };
  

  if (!userData) {
    return (
      <Typography
        variant="h4"
        sx={{ display: "flex", justifyContent: "center", marginTop: 20 }}
      >
        Please Enroll to see your Details
      </Typography>
    );
  }

  return (
    <Container sx={{ paddingTop: "20px" }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {userData2 && (
          <Avatar
            alt={userData.fullname}
            src={`http://localhost:5000/uploads/${userData2.second_photo}`}
            sx={{ width: 100, height: 100 }}
          />
        )}
      </Box>
      <Box
        sx={{ display: "flex", alignItems: "center", float: "inline-start" }}
      >
        {userData2 && (
          <CardMedia
            component="img"
            sx={{
              height: "50vh",
              width: "auto",
              padding: "20px",
              paddingLeft: "20px",
              display: "flex",
            }}
            image={`http://localhost:5000/uploads/${userData2.first_photo}`}
            alt="User Photo"
          />
        )}
      </Box>
      <Box
        sx={{ display: "flex", flexDirection: "column", paddingLeft: "85px" }}
      >
        {editMode ? (
          <>
            <TextField
              label="Name"
              name="fullname"
              value={formData.fullname || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="E-mail"
              name="email"
              value={formData.email || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Phone"
              name="phnumber"
              value={formData.phnumber || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Complexion"
              name="complexion"
              value={formData.complexion || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Date Of Birth"
              name="date"
              value={formData.date || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Address"
              name="address"
              value={formData.address || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Height"
              name="height"
              value={formData.height || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Sub Cast"
              name="subcast"
              value={formData.subcast || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Blood Group"
              name="bloodgroup"
              value={formData.bloodgroup || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Diet"
              name="diet"
              value={formData.diet || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Lens"
              name="lens"
              value={formData.lens || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Rashi"
              name="rashi"
              value={formData.rashi || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Nakshatra"
              name="nakshatra"
              value={formData.nakshatra || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Education Area"
              name="educationarea"
              value={formData.educationarea || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Education"
              name="education"
              value={formData.education || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Occupation"
              name="occupationdetails"
              value={formData.occupationdetails || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Income"
              name="income"
              value={formData.income || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Working City"
              name="workingcity"
              value={formData.workingcity || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Father"
              name="father"
              value={formData.father || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Mother"
              name="mother"
              value={formData.mother || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Brother"
              name="brother"
              value={formData.brother || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Sister"
              name="sister"
              value={formData.sister || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Married Brother"
              name="married_brother"
              value={formData.married_brother || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Married Sister"
              name="married_sister"
              value={formData.married_sister || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Father Occupation"
              name="fatheroccupation"
              value={formData.fatheroccupation || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <TextField
              label="Mother Occupation"
              name="motheroccupation"
              value={formData.motheroccupation || ""}
              onChange={handleInputChange}
              sx={{ margin: 1 }}
            />
            <Button
              variant="contained"
              color="primary"
              sx={{ margin: 1 }}
              onClick={handleSubmit}
            >
              Save
            </Button>
          </>
        ) : (
          <>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Name : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 20 }}
              >
                {userData.fullname}
              </Typography>
            </Box>
            <Button
              variant="contained"
              color="primary"
              sx={{ margin: 1 }}
              onClick={() => setEditMode(true)}
            >
              Edit
            </Button>
          </>
        )}
      </Box>
      <ToastContainer position="top-center" />
    </Container>
  );
}
