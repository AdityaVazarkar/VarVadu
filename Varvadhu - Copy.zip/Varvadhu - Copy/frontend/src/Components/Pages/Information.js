import React, { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import CloseIcon from "@mui/icons-material/Close";
import Slide from "@mui/material/Slide";
import { Avatar, Container, CardMedia } from "@mui/material";
import Box from "@mui/material/Box";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const Information = ({ user }) => {
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const Intrest = () => {
    // Here you can send a notification to the user's dashboard
    // You can make an axios POST request to your server to send the notification
    axios.post(`http://localhost:5000/notify/${user.email}`)
      .then((res) => {
        toast.success("Interest sent");
      })
      .catch((err) => {
        console.log(err);
        toast.error("Failed to send interest");
      });
  };

  return (
    <>
      <Button
        onClick={handleClickOpen}
        variant="contained"
        color="primary"
        sx={{ display: "block", margin: "auto", marginTop: "20px" }}
      >
        More Information
      </Button>

      <Dialog
        fullScreen
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <AppBar sx={{ position: "relative" }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              More Information
            </Typography>
            <Button autoFocus color="inherit" onClick={handleClose}>
              Close
            </Button>
          </Toolbar>
        </AppBar>
        <Container sx={{ paddingTop: "20px" }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              float: "inline-start",
            }}
          >
            <CardMedia
              component="img"
              sx={{
                height: "50vh",
                width: "auto",
                padding: "20px",
                paddingLeft: "20px",
                display: "flex",
              }}
              image={user.image}
              alt="Profile Picture"
            />
          </Box>

          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              paddingLeft: "85px",
            }}
          >
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                paddingLeft: "85px",
              }}
            >
              <Box sx={{ display: "inline-flex", margin: 5 }}>
                <Typography variant="h6">Name : -</Typography>
                <Typography
                  variant="h6"
                  color="textSecondary"
                  component="span"
                  sx={{ paddingLeft: 20 }}
                >
                  {user.name}
                </Typography>
              </Box>

              {/* Other user information */}
              
              <Button variant="contained" sx={{ margin: 5 }} onClick={Intrest}>
                Show Interest
              </Button>
            </Box>
          </Box>

          <ToastContainer position="top-center" />
        </Container>
      </Dialog>
    </>
  );
};

export default Information;
