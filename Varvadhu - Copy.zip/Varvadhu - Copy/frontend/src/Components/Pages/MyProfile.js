import React, { useEffect, useState } from "react";
import axios from "axios";
import Typography from "@mui/material/Typography";
import { Avatar, Container, Box, CardMedia, Button } from "@mui/material";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";

export default function MyProfile() {
  const [userData, setUserData] = useState(null);
  const [userData1, setUserData1] = useState(null);
  const [userData3, setUserData3] = useState(null);

  const navigate = useNavigate()
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        // Get user email from sessionStorage
        const userEmail = sessionStorage.getItem("user");

        if (!userEmail) {
          console.error("No user email found in sessionStorage");
          return;
        }

        // Fetch user data based on the email
        const response = await axios.get(
          `http://localhost:5000/userdata?email=${userEmail}`
        );
        const response1 = await axios.get(
          `http://localhost:5000/userdata1?email=${userEmail}`
        );
        const response2 = await axios.get(
          `http://localhost:5000/userdata3?email=${userEmail}`
        );

        // Set user data based on the responses
        setUserData(response.data[0]);
        setUserData1(response1.data[0]);
        setUserData3(response2.data[0]);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  if (!userData) {
    return (
      <Typography
        variant="h4"
        sx={{ display: "flex", justifyContent: "center", marginTop: 20 }}
      >
        Please Enroll to see your Details
      </Typography>
    );
  }

  return (
    <Container sx={{ paddingTop: "20px" }}>
      {/* <NavBar /> */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {userData3 && (
          <Avatar
            alt={userData.fullname}
            src={`http://localhost:5000/uploads/${userData3.second_photo}`}
            sx={{ width: 100, height: 100 }}
          />
        )}
      </Box>
      <Box
        sx={{ display: "flex", alignItems: "center", float: "inline-start" }}
      >
        {userData3 && (
          <CardMedia
            component="img"
            sx={{
              height: "50vh",
              width: "auto",
              padding: "20px",
              paddingLeft: "20px",
              display: "flex",
            }}
            image={`http://localhost:5000/uploads/${userData3.first_photo}`}
            alt="User Photo"
          />
        )}
      </Box>
      <Box
        sx={{ display: "flex", flexDirection: "column", paddingLeft: "85px" }}
      >
        {userData && (
          <>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Name : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 20 }}
              >
                {userData.fullname}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">E-mail : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 20 }}
              >
                {userData.email}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Phone : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 20 }}
              >
                {userData.phnumber}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Complexion : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 14 }}
              >
                {userData.complexion}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Date Of Birth : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 13 }}
              >
                {userData.date}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Address : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 18 }}
              >
                {userData.address}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">height:-</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 22 }}
              >
                {userData.height}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Sub Cast : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 17 }}
              >
                {userData.subcast}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Blood Group : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 14 }}
              >
                {userData.bloodgroup}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Diet : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 23 }}
              >
                {userData.diet}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Lence : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 21 }}
              >
                {userData.lens}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Rashi : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 21 }}
              >
                {userData1.rashi}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Nakshatra : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 16 }}
              >
                {userData1.nakshatra}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Education Area : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 10 }}
              >
                {userData1.educationarea}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Education : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 16 }}
              >
                {userData1.education}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Occupation : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 14 }}
              >
                {userData1.occupationdetails}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Income : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 18 }}
              >
                {userData1.income}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">working city : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 14 }}
              >
                {userData1.workingcity}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">father : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 20 }}
              >
                {userData3.father}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">mother : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 19 }}
              >
                {userData3.mother}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">brother : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 19 }}
              >
                {userData3.brother}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">sister : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 21 }}
              >
                {userData3.sister}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">married brother : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 10 }}
              >
                {userData3.married_brother}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">married Sister : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 12 }}
              >
                {userData3.married_sister}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Father Occupation : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 7 }}
              >
                {userData3.fatheroccupation}
              </Typography>
            </Box>
            <Box sx={{ display: "inline-flex", margin: 5 }}>
              <Typography variant="h6">Mother Occupation : -</Typography>
              <Typography
                variant="h6"
                color="textSecondary"
                component="span"
                sx={{ paddingLeft: 6 }}
              >
                {userData3.motheroccupation}
              </Typography>
            </Box>
          </>
        )}
      </Box>
      <Button variant="contained" sx={{background:"red", display:'block', margin:'auto'}} onClick={()=>navigate("/editmyprofile")}>Edit</Button>

      <ToastContainer position="top-center" />
    </Container>
  );
}


