import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Avatar,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
  Typography,
} from "@mui/material";
import axios from "axios";
import bcrypt from "bcryptjs";
import { ToastContainer, toast } from "react-toastify";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import LockOpenIcon from "@mui/icons-material/LockOpen";
import LoginIcon from "@mui/icons-material/Login";
import LoginForm from "../LoginForm";

function Register() {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState({
    name: "",
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleInput = (event) => {
    setValue((prev) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
  };

  const [errors, setErrors] = useState({
    name: "",
    email: "",
    password: "",
  });

  const validateEmail = (email) => {
    const emailRegex = /^[a-z][a-zA-Z0-9]*@gmail\.(com|in)$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password) => {
    // Password must contain at least 8 characters, one uppercase letter, one lowercase letter, and one number
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return passwordRegex.test(password);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    let valid = true;

    // Validate fields
    if (value.name === "") {
      setErrors((prev) => ({ ...prev, name: "Name is required" }));
      valid = false;
    } else {
      setErrors((prev) => ({ ...prev, name: "" }));
    }

    if (value.email === "") {
      setErrors((prev) => ({ ...prev, email: "Email is required" }));
      valid = false;
    } else if (!validateEmail(value.email)) {
      setErrors((prev) => ({ ...prev, email: "Invalid email format" }));
      valid = false;
    } else {
      setErrors((prev) => ({ ...prev, email: "" }));
    }

    if (value.password === "") {
      setErrors((prev) => ({ ...prev, password: "Password is required" }));
      valid = false;
    } else if (!validatePassword(value.password)) {
      setErrors((prev) => ({
        ...prev,
        password:
          "Password must be at least 8 characters long, contain one uppercase letter, one lowercase letter, and one number",
      }));
      valid = false;
    } else {
      setErrors((prev) => ({ ...prev, password: "" }));
    }

    if (!valid) {
      return;
    }

    try {
      // Encrypt password
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(value.password, salt);

      const res = await axios.post("http://localhost:5000/signup", {
        ...value,
        password: hashedPassword,
      });

      if (res.data.status === "success") {
        alert("User registered successfully");
        navigate("/");
      } else if (res.data.status === "error") {
        alert("User already exists");
      }
    } catch (err) {
      console.error("An error occurred:", err);
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setOpen(false);
    }
  };

  const handleClose = () => {
    setOpen(false);
    // Reset form and errors on close
    setValue({
      name: "",
      email: "",
      password: "",
    });
    setErrors({
      name: "",
      email: "",
      password: "",
    });
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  return (
    <>
      <Button
        sx={{ display: "block", my: 2, color: "black", zIndex: 2 }}
        onClick={handleClickOpen}
        startIcon={<LockOpenIcon />}
      >
        Register
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>
          <Box sx={{ textAlign: "center" }}>
            <Avatar
              sx={{
                m: 1,
                bgcolor: "secondary.main",
                alignContent: "center",
                display: "inline-block",
              }}
            >
              <LockOutlinedIcon />
            </Avatar>
            <Typography component="h1" variant="h5">
              Register
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            To register on this website, please enter your name, email address, and password.
          </DialogContentText>

          <form onSubmit={handleSubmit}>
            <TextField
              error={!!errors.name}
              helperText={errors.name}
              margin="dense"
              id="name"
              name="name"
              label="Name"
              type="text"
              fullWidth
              value={value.name}
              onChange={handleInput}
              className="block border border-grey-light w-full p-3 rounded mb-4"
            />
            <TextField
              error={!!errors.email}
              helperText={errors.email}
              margin="dense"
              id="email"
              name="email"
              label="Email Address"
              type="email"
              fullWidth
              value={value.email}
              onChange={handleInput}
              className="block border border-grey-light w-full p-3 rounded mb-4"
            />
            <TextField
              error={!!errors.password}
              helperText={errors.password}
              margin="dense"
              id="password"
              name="password"
              label="Password"
              type="password"
              fullWidth
              value={value.password}
              onChange={handleInput}
              className="block border border-grey-light w-full p-3 rounded mb-4"
            />
          </form>
        </DialogContent>
        <LoginForm />
        <DialogActions>
          <Button
            onClick={handleClose}
            variant="contained"
            sx={{ backgroundColor: "red" }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            color="primary"
            variant="contained"
            startIcon={<LoginIcon />}
          >
            Sign up
          </Button>
        </DialogActions>
      </Dialog>
      <ToastContainer />
    </>
  );
}

export default Register;
