import React from 'react';
import { Container, Typography, Divider } from '@mui/material';

const Rules = () => {
    return (
        <Container maxWidth="md" sx={{ mt: 4 }}>
            <Typography variant="h1" gutterBottom sx={{textAlign:'center'}}>
                Rules 
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Typography variant="h6" gutterBottom>
                1. Respect and Courtesy
            </Typography>
            <Typography variant="body1" paragraph>
                Treat others on varvadhu.com with respect and courtesy at all times. Harassment, abuse, or inappropriate behavior towards other users will not be tolerated.
            </Typography>
            <Typography variant="h6" gutterBottom>
                2. Authenticity
            </Typography>
            <Typography variant="body1" paragraph>
                Provide accurate and truthful information about yourself on your profile. False information may result in the suspension of your account.
            </Typography>
            <Typography variant="h6" gutterBottom>
                3. Privacy
            </Typography>
            <Typography variant="body1" paragraph>
                Respect the privacy of other users. Do not share personal contact information, such as phone numbers or addresses, on public platforms.
            </Typography>
            <Typography variant="h6" gutterBottom>
                4. Communication
            </Typography>
            <Typography variant="body1" paragraph>
                Communicate respectfully and responsibly with other users. Offensive language or behavior will not be tolerated.
            </Typography>
        </Container>
    );
};

export default Rules;
