import React from "react";
import Home from "./Home";
import Footer from "../Footer";
function HomePage() {
  return (
    <div>
      <Home />

      <Footer />
    </div>
  );
}

export default HomePage;
