import React from 'react';
import { makeStyles } from '@mui/styles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Box } from '@mui/material';

const useStyles = makeStyles({
  card: {
    Width: 'auto',
    minWidth:'397px',
    borderRadius: 30,
    margin: '20px',
    boxShadow: '0 4px 8px 0 rgba(0,0,0,0.2)',
    transition: 'all 0.3s ease-in-out',
    '&:hover': {
      transform: 'translateY(-5px)',
      boxShadow: '10px 8px 16px 10px rgba(0,0,0,0.2)',
    },
  },
  media: {
    objectFit: 'cover',
    borderRadius: '20px 20px 0 0',
    // boxShadow: '0 4px 8px 0 rgba(0,0,0,0.2)',
    transition: '0.3s',
    '&:hover': {
      boxShadow: '0 8px 16px 0 rgba(0,0,0,0.2)',
    },
  },
  avatar: {
    width: 100,
    height: 100,
    border: '4px solid #fff',
    margin: '-50px auto 0',
    zIndex: 1,
    backgroundImage: './shadi_home_img'
  },
  content: {
    textAlign: 'left',
  },
  infoContainer: {
    display: 'flex',
    justifyContent: 'space-between',
  },
  infoText: {
    display: 'block',
    textAlign: 'center'
  },
});

const Cards = ({ name,sname, slocation, location, description, avatarUrl, image }) => {
  const classes = useStyles();

  return (
    <Card className={classes.card}>
      <CardMedia
        className={classes.media}
        sx={{ height: '500px' }}
       image={image}
        title={name}
      />
      <CardContent className={classes.content}>
        <Box >
          <Typography variant='h6' sx={{ display: 'flex',justifyContent:'center' }} >
            Name : -
          </Typography>
        <Box sx={{display:'flex',justifyContent:"space-around"}}>
          <Typography
            variant="body2"
            color="textSecondary"
            component="span"
          
            className={classes.infoText}
          >
            {name} 
          </Typography>
          <Typography
            variant="body2"
            color="textSecondary"
            component="span"
            
            className={classes.infoText}
          >
            {sname} 
          </Typography>
        </Box>
        </Box>
        <Box >
          <Typography variant='h6' sx={{ display: 'flex',justifyContent:'center' }} >
            Location : -
          </Typography>
        <Box sx={{display:'flex',justifyContent:"space-around"}}>
          <Typography
            variant="body2"
            color="textSecondary"
            component="span"
          
            className={classes.infoText}
          >
            {location} 
          </Typography>
          <Typography
            variant="body2"
            color="textSecondary"
            component="span"
            
            className={classes.infoText}
          >
            {slocation} 
          </Typography>
        </Box>
        </Box>
        
        <Box>
          <Typography variant='h6' sx={{ display: 'flex',justifyContent:'center' }}>
            Description : -
          </Typography>
          <Typography
            variant="body2"
            color="textSecondary"
            component="span"
            className={classes.infoText}
          >
            {description} 
          </Typography>
        </Box>
        <Box  >
        </Box>
      </CardContent>
    </Card>
  );
};

export default Cards;
