import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import PropTypes from "prop-types";
import Information from "./Pages/Information";

const useStyles = makeStyles({
  card: {
    width: 300,
    transition: "transform 0.3s ease-in-out", 
    "&:hover": {
      transform: "translateY(-5px)",
    },
  },
  media: {
    height: 370,
  },
  cardHover: {
    "&:hover ": {
      opacity: 1,
      paddingTop: 10,
      borderTop: "1px solid #ccc",
    },
  },
});

const ProfileCard = (props) => {
  const classes = useStyles();
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  return (
    <Card
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onHover={isHovered}
      sx={{
        maxWidth: 300,
        width: 300,
        margin: 5,
        height:'auto',
        transition: "transform 0.3s ease-in-out",
        "&:hover": {
          transform: "translateY(-5px)",
          boxShadow: "0 10px 10px 0 rgba(0,0,0,0.2)",
        },
      }}
    >
      <CardMedia
        className={classes.media}
        image={props.image}
        // image="./shadi_home_img.jpg"
        title="Profile Picture"
      />

      <CardContent sx={{ height: "210px" }}>
        <Typography gutterBottom variant="h5" component="h2">
          {props.name}
        </Typography>
        <Typography variant="body2" color="textSecondary" component="p">
          Age: {props.age}
        </Typography>
        <Typography variant="body2" color="textSecondary" component="p">
          Location: {props.workingcity}
        </Typography>
        <Typography variant="body2" color="textSecondary" component="p">
        occupation: {props.occupationtype}
        </Typography>
        <Information user={props} />
      </CardContent>
    </Card>
  );
};

ProfileCard.propTypes = {
  name: PropTypes.string.isRequired,
  age: PropTypes.number.isRequired,
  workingcity: PropTypes.string.isRequired,
  occupationtype: PropTypes.string.isRequired,
};

export default ProfileCard;
