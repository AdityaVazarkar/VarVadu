import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  TextField,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import StripeCheckout from "react-stripe-checkout";

const useStyles = makeStyles({
  card: {
    maxWidth: 300,
    margin: 20,
    marginTop: 20,
    padding: 20,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    boxShadow: "0 4px 8px 0 rgba(0, 0, 0, 0.2)",
    borderRadius: 10,
    backgroundColor: "#f0f0f0",
    transition: "all transform 1s 1s ease-in-out",
    "&:hover": {
      boxShadow: "0 8px 16px 0 rgba(0,0,0,0.2)",
      transform: "translateY(-5px)",
    },
  },
  header: {
    marginBottom: 10,
    fontWeight: "bold",
    color: "#333",
  },
  memberInfo: {
    marginBottom: 20,
    color: "#555",
  },
  expiration: {
    color: "#f44336",
    fontWeight: "bold",
  },
});

const MembershipCard = ({ image, name, membershipType, expiration, amount }) => {
  const classes = useStyles();
  const navigate = useNavigate();
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  const handleMembershipButtonClick = () => {
    navigate("/membership");
  };

  const user = sessionStorage.getItem("user");
  const handleToken = async (token) => {
    // console.log(customerName,token.email,token.id);
    
    // try {
    //   const response = await fetch("/api/addUser", {
    //     method: "POST",
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //     body: JSON.stringify({
    //       token: token.id,
    //       name: customerName,
    //       email: token.email,
    //     }),
    //   });
    //   if (response.ok) {
    //     toast.success("Payment successful!");
    //   } else {
    //     toast.error("Failed to add user.");
    //   }
    // } catch (error) {
    //   console.error("Error:", error);
    //   toast.error("Something went wrong.");
    // }
    alert("payment successful")
  };


  return (
    <>
      <Card className={classes.card} elevation={3}>
        <CardContent>
          <Typography variant="h5" component="h2" className={classes.header}>
            {membershipType} Membership
          </Typography>
          <CardMedia
            sx={{ height: "180px", width: "260px", marginLeft: "-17px" }}
            image={image}
            title={name}
          />
          <Typography color="textSecondary" gutterBottom className={classes.memberInfo}>
            Membership Type: {membershipType}
          </Typography>
          <Typography variant="body2" component="p" className={classes.expiration}>
            Expires: {expiration}
          </Typography>
          <Typography variant="p" className={classes.memberInfo}>
            *This membership card is non-transferable.
          </Typography>
          <br />
          {/* <TextField
            label="Cardholder's Name"
            variant="outlined"
            value={customerName}
            onChange={handleNameChange}
            fullWidth
            margin="normal"
          /> */}
          <br />
          {isAuthenticated ? (
            <StripeCheckout
              image="../logo.jpg"
              locale="auto"
              label="Pay"
              amount={amount}
              email={user}
              currency="INR"
              description={membershipType + " Membership"}
              name={membershipType + " Membership"}
              token={handleToken}
              stripeKey="pk_test_51PHgoESJJuA0tBlyI1OET4DUnmeDxnSdaN5TxHQvOzgwfccAzaToBLZidLxl6jN1dJjp8QbS0uWImRBhs355AKce00Vop79Ucw"
            />
          ) : (
            <Typography variant="h6" className="bold-text">
              Please login to your account to get membership
            </Typography>
          )}
        </CardContent>
      </Card>
      <ToastContainer />
    </>
  );
};

export default MembershipCard;
