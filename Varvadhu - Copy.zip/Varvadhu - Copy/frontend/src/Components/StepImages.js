import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import SwipeableViews from 'react-swipeable-views';
import { autoPlay } from 'react-swipeable-views-utils';
import { MobileStepper } from '@mui/material';

const AutoPlaySwipeableViews = autoPlay(SwipeableViews);

const images = [
  // {
  //   imgPath: 'PerfectMatch.jpeg',
  // },
  {
    id:1,
    imgPath: 'banner1.jpg',
  },
  {
    id:2,
    imgPath: 'indian-wedding-couple.jpg',
  },
  {
    id:3,
    imgPath: 'ritual.jpg',
  },
  // {
  //   imgPath: 'banner.jpeg',
  // },
];

function StepImages() {
  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const maxSteps = images.length;

  const handleStepChange = (step) => {
    setActiveStep(step);
  };

  // Sample side content
  const sideContent = (
    <Box>
      <h2>Additional Content</h2>
      <p>This is some additional content that will be displayed alongside the images.</p>
    </Box>
  );
  

  return (
    <Box sx={{ display: 'flex', flexDirection: 'row' }}>
      {/* Render the side content */}

      {/* Render the images */}
      <Box sx={{ flex: 2 }}>
        <AutoPlaySwipeableViews
          axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
          index={activeStep}
          onChangeIndex={handleStepChange}
          enableMouseEvents
        >
          {images.map((step, index) => (
            <div key={step.id}>
              {Math.abs(activeStep - index) <= 2 ? (
                <Box
                  sx={{
                    mt: 5,
                    height: '465px',
                    display: 'block',
                    overflow: 'hidden',
                    width: '98.9vw',
                    paddingLeft: 9,
                    paddingRight: 9
                  }}
                >
                  <Box sx={{float:'right' }}>{sideContent[index]}</Box>
                  <img src={step.imgPath} alt={'images'} />
                </Box>



              ) : null}
            </div>
          ))}
        </AutoPlaySwipeableViews>
        <Box sx={{ mt: 2 }}>
          <MobileStepper
            variant="dots"
            shape="rounded"
            position="static"
            steps={maxSteps}
            activeStep={activeStep}
            nextButton={null}
            backButton={null}
            onChange={(event, value) => handleStepChange(value)}
          />
        </Box>
      </Box>
    </Box>
  );
}

export default StepImages;
