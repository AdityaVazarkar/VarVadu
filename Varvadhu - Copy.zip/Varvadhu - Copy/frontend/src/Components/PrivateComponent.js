import React from 'react'
import { Outlet } from 'react-router-dom'
import Profiles from './Pages/Profiles'

const PrivateComponent = ({ isAuthenticated }) => {
  return (
      <div>
          <>
          { isAuthenticated?<Outlet/>:<Profiles/> }
          </>
    </div>
  )
}

export default PrivateComponent