import * as React from "react";
import { Link, NavLink, Route, Routes, useNavigate } from "react-router-dom";
import { LogoutUser } from "../Redux/Actions/Authactions";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import AccountCircle from "@mui/icons-material/AccountCircle";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import { Avatar, Button } from "@mui/material";
import { Dashboard, Logout, Settings } from "@mui/icons-material";
// import Home from "./Pages/Home";
// import About from "./Pages/About";
// import Contact from "./Pages/Contact";
// import SucessStories from "./Pages/SucessStories";
import Register from "./Pages/Register";

import { useDispatch, useSelector } from "react-redux";
import LoginForm from "./LoginForm";

const pagesAndLinks = [
  { name: "Home", link: "/" },
  { name: "Rules", link: "/rules" },
  { name: "Enroll", link: "/register" },
  { name: "Contact", link: "/contact" },
  { name: "About", link: "/about" },
  { name: "Success Stories", link: "/successstories" },
];

function NavBar() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [anchorElNav, setAnchorElNav] = React.useState(null);

  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  const dispatch = useDispatch();

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const navigate = useNavigate();

  const handleClose = () => {
    setAnchorEl(null);
  };
  const NaviToDashBoard = () => {
    navigate("/dashboard");
    setAnchorEl(null);
  };

  const Logout = () => {
    handleClose();
    sessionStorage.removeItem("user");
    dispatch(LogoutUser());
  };

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  React.useEffect(() => {
    navigate("/");
  }, [isAuthenticated]);

  return (
    <Box sx={{ flexGrow: 1, backgroundColor: "white", zIndex: 1 }}>
      <AppBar position="static">
        <Toolbar
          sx={{
            height: "65px",
            backgroundColor: "#dbb6bd",
            background: "linear-gradient(to right, #ffffff, #ffffff)",
          }}
        >
          <Typography
            variant="h6"
            noWrap
            component={NavLink}
            to="/"
            sx={{
              mr: 2,
              display: { xs: "none", md: "flex" },
              justifyContent: "center",
              fontWeight: 700,
              marginLeft: 15,
              marginTop: 0,
              color: "inherit",
              textDecoration: "none",
              zIndex: 2,
              "&:hover": {
                transform: "scale(1.1)", // Example hover effect: increase size
                transition: "transform 0.3s ease-in-out", // Add smooth transition
              },
            }}
          >
            <Avatar
              src="../logo.jpg"
              sx={{
                width: 50,
                height: 50,
              }}
            />
          </Typography>

          <Box
            sx={{
              flexGrow: 1,
              display: { xs: "flex", md: "none" },
              marginLeft: 5,
              zIndex: 2,
            }}
          >
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              sx={{ color: "white" }}
            >
              <MenuIcon />
            </IconButton>
            {/* {isAuthenticated ? ( */}
            {/* <> */}
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              keepMounted
              transformOrigin={{
                vertical: "top",
                horizontal: "left",
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: "block", md: "none", zIndex: 2 },
              }}
            >
              {pagesAndLinks.map((page) => (
                <MenuItem key={page.name} onClick={handleCloseNavMenu}>
                  <NavLink
                    to={page.link}
                    style={{
                      textDecoration: "none",
                      color: "black",
                      zIndex: 2,
                    }}
                  >
                    {page.name}
                  </NavLink>
                </MenuItem>
              ))}
            </Menu>
            {/* </> */}
            {/* ) : null} */}
          </Box>
          <Typography
            variant="h5"
            noWrap
            component={NavLink}
            to="/"
            sx={{
              mr: 2,
              display: { xs: "flex", md: "none" },
              flexGrow: 1,
              zIndex: 2,
              marginRight: 15,
              "&:hover": {
                transform: "scale(1.1)", // Example hover effect: increase size
                transition: "transform 0.3s ease-in-out", // Add smooth transition
              },
            }}
          >
            <Avatar src="../logo.jpg" sx={{ width: 60, height: 60 }} />
          </Typography>
          <Box
            sx={{
              flexGrow: 1,
              display: {
                xs: "none",
                md: "flex",
                marginLeft: "90px",
                zIndex: 2,
              },
            }}
          >
            {pagesAndLinks.map((page) => (
              <Button
                key={page.name}
                component={NavLink}
                to={page.link}
                onClick={handleCloseNavMenu}
                sx={{ my: 2, color: "black", display: "block" }}
              >
                {page.name}
              </Button>
            ))}
          </Box>
          {isAuthenticated ? (
            <Box sx={{ position: "absolute", right: 20, display: "flex" }}>
              <Button
                component={NavLink}
                to="/profiles"
                sx={{ my: 2, color: "black", display: "block", zIndex: 2 }}
                onClick={handleClose}
              >
                Profiles
              </Button>
              <IconButton
                size="large"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                sx={{ zIndex: 2, color: "black", alignItems: "center" }}
                color="#3170d4"
              >
                <AccountCircle />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                  zIndex: 2,
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                  zIndex: 2,
                }}
                open={Boolean(anchorEl)}
                onClose={handleClose}
              >
                <MenuItem onClick={() => navigate("/myprofile")}>
                  My profile
                </MenuItem>
                <MenuItem onClick={() => navigate("/dashboard/*")}>
                  Dashboard
                </MenuItem>
                <MenuItem onClick={Logout}>Log Out</MenuItem>
              </Menu>
            </Box>
          ) : (
            <Box
              sx={{
                position: "absolute",
                right: 20,
                display: "flex",
                color: "white",
              }}
            >
              <Register />
              <LoginForm />
            </Box>
          )}
        </Toolbar>
      </AppBar>
    </Box>
  );
}

export default NavBar;
