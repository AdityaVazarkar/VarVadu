import * as React from "react";
import BottomNavigation from "@mui/material/BottomNavigation";
import BottomNavigationAction from "@mui/material/BottomNavigationAction";
import InstagramIcon from "@mui/icons-material/Instagram";
import Facebook from "@mui/icons-material/Facebook";
import LinkedIn from "@mui/icons-material/LinkedIn";
import Twitter from "@mui/icons-material/Twitter";
import { Box, Typography } from "@mui/material";
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles({

  FooterInfo: {
    marginBottom: 20,
    color: '#555',
  },
  expiration: {
    color: '#f44336', // Red color for expiration date
    fontWeight: 'bold',
  },
  
  Info: {
    display: "inline-block",
    margin: 5

  },
});
export default function Footer() {
  const [value, setValue] = React.useState("recents");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const classes = useStyles();

  return (
    <>
      <BottomNavigation
        sx={{ width: "100%", borderTop: "1px solid #ccc",bottom:0, background: 'linear-gradient(to right, #c86d6d, #f4d7f8)'}}
        value={value}
        onChange={handleChange}
      >
        <BottomNavigationAction
          href=""
          label="Facebook"
          value="Facebook"
          icon={<Facebook sx={{ color: "#0773e6" }} />}
        />
        <BottomNavigationAction
          href=""
          label="linkedin"
          value="linkedin"
          icon={<LinkedIn sx={{ color: "#0b7db8" }} />}
        />
        <BottomNavigationAction
          href=""
          label="Instagram"
          value="Instagram"
          icon={<InstagramIcon sx={{ color: "#ff00fcd6" }} />}
        />
        <BottomNavigationAction
          href=""
          label="twitter"
          value="twitter"
          icon={<Twitter sx={{ color: "#1da1f2" }} />}
        />
      </BottomNavigation>
      {/* <BottomNavigation> */}
      <Box sx={{background: 'linear-gradient(to right, #c86d6d, #f4d7f8)',display:"flex",justifyContent:'space-evenly'}}>
        
        <Box className={classes.Info}>
          <Typography variant="h6" sx={{ display: "block" }}>
          Owner:
          </Typography>
          <Typography
            variant="h6"
            color="textSecondary"
            component="span"
          >
            Name of the owner
          </Typography>
        </Box>
        <Box className={classes.Info}>
          <Typography variant="h6" sx={{ display: "block" }}>
          Contact:
          </Typography>
          <Typography
            variant="h6"
            color="textSecondary"
            component="span"
          >
            1234567890
          </Typography>
        </Box>
        <Box className={classes.Info}>
          <Typography variant="h6" sx={{ display: "block" }}>
          email:
          </Typography>
          <Typography
            variant="h6"
            color="textSecondary"
            component="span"
          >
            info@gmail.com
          </Typography>
        </Box>

      </Box>
    </>
  );
}



