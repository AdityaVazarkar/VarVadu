import React, { useState } from "react";
import { useDispatch } from "react-redux";
import axios from "axios";
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  DialogContentText,
  Box,
  Avatar,
  Typography,
} from "@mui/material";
import LoginIcon from "@mui/icons-material/Login";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { Login } from "../Redux/Actions/Authactions";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import Register from "./Pages/Register";

function Copyright() {
  return (
    <Typography variant="body2" color="text.secondary" align="center">
      {'Copyright © '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

function LoginForm() {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    // Reset form and errors on close
    setValue({
      email: "",
      password: "",
    });
    setErrors({
      email: "",
      password: "",
    });
  };

  const handleInput = (event) => {
    setValue((prev) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
  };

  const dispatch = useDispatch();

  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .post("http://localhost:5000/login", value)
      .then((res) => {
        if (res.data.Login) {
          sessionStorage.setItem("user", value.email);
          navigate("/register");
          alert("Login Successfully");

          handleClose();
          dispatch(Login(value));
        } else {
          alert("No record");
        }
        console.log(res);
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="flex justify-center items-center">
      <ToastContainer />
      <Button
        sx={{ display: 'block', my: 2, color: "black", zIndex: 2 }}
        onClick={handleClickOpen}
        startIcon={<LoginIcon />}
      >
        Login
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>
          <Box sx={{ textAlign: "center" }}>
            <Avatar
              sx={{
                m: 1,
                bgcolor: "secondary.main",
                alignContent: "center",
                display: "inline-block",
              }}
            >
              <LockOutlinedIcon />
            </Avatar>
            <Typography component="h1" variant="h5">
              Sign in
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            To Login to this website, Please enter your email address and
            password
          </DialogContentText>

          <form onSubmit={handleSubmit}>
            <TextField
              error={!!errors.email}
              helperText={errors.email}
              margin="dense"
              id="email"
              name="email"
              label="Email Address"
              type="email"
              fullWidth
              value={value.email}
              onChange={handleInput}
              className="block border border-grey-light w-full p-3 rounded mb-4"
            />
            <TextField
              error={!!errors.password}
              helperText={errors.password}
              margin="dense"
              id="password"
              name="password"
              label="Password"
              type="password"
              fullWidth
              value={value.password}
              onChange={handleInput}
              className="block border border-grey-light w-full p-3 rounded mb-4"
            />
          </form>
        </DialogContent>
        <Copyright />
        <Register />
        <DialogActions>
          <Button
            onClick={handleClose}
            variant="contained"
            sx={{ backgroundColor: "red" }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            color="primary"
            variant="contained"
            startIcon={<LoginIcon />}
          >
            Sign in
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default LoginForm;
