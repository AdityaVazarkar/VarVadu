import React, { useState } from 'react';
import {
  TextField,
  Button,
  FormControl,
  Container,
  Typography,
  Input,
} from '@mui/material';
import axios from 'axios';

const Success = () => {
  const [name, setName] = useState('');
  const [sname, setSname] = useState('');
  const [location, setLocation] = useState('');
  const [slocation, setSlocation] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const [errors, setErrors] = useState({});

  // Handle input changes
  const handleInput = (event) => {
    if (event.target.name === 'photo') {
      setFile(event.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const errors = {};
    if (!name) errors.name = 'Name is required';
    if (!sname) errors.sname = 'Partner Name is required';
    if (!location) errors.location = 'Location is required';
    if (!slocation) errors.slocation = 'Partner Location is required';
    if (!description) errors.description = 'Description is required';
    if (!file) errors.file = 'File is required';
    setErrors(errors);

    if (Object.keys(errors).length === 0) {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('sname', sname);
      formData.append('location', location);
      formData.append('slocation', slocation);
      formData.append('description', description);
      formData.append('file', file);

      try {
        const res = await axios.post('http://localhost:5000/success', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        alert('Data Submitted');
        console.log(res.data);
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <Container>
      <h2 className="text-center">
        We will Share this information to the Success Stories
      </h2>
      <form onSubmit={handleSubmit}>
        <FormControl fullWidth margin="normal">
          <TextField
            value={name}
            label="Name"
            name="name"
            onChange={(e) => setName(e.target.value)}
            error={!!errors.name}
            helperText={errors.name}
          />
        </FormControl>
        <FormControl fullWidth margin="normal">
          <TextField
            value={sname}
            label="Partner Name"
            name="sname"
            onChange={(e) => setSname(e.target.value)}
            error={!!errors.sname}
            helperText={errors.sname}
          />
        </FormControl>
        <FormControl fullWidth margin="normal">
          <TextField
            value={location}
            label="Location"
            name="location"
            onChange={(e) => setLocation(e.target.value)}
            error={!!errors.location}
            helperText={errors.location}
          />
        </FormControl>
        <FormControl fullWidth margin="normal">
          <TextField
            value={slocation}
            label="Partner location"
            name="slocation"
            onChange={(e) => setSlocation(e.target.value)}
            error={!!errors.slocation}
            helperText={errors.slocation}
          />
        </FormControl>
        <FormControl fullWidth margin="normal">
          <TextField
            value={description}
            label="Description"
            name="description"
            multiline
            rows={4}
            onChange={(e) => setDescription(e.target.value)}
            error={!!errors.description}
            helperText={errors.description}
          />
        </FormControl>
        <FormControl fullWidth margin="normal">
          <Typography variant="body1">Upload your picture</Typography>
          <Input type="file" name="photo" onChange={handleInput} />
          {errors.file && <Typography color="error">{errors.file}</Typography>}
        </FormControl>
        <Button type="submit" variant="contained" color="primary">
          Submit
        </Button>
      </form>
    </Container>
  );
};

export default Success;
