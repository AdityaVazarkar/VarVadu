import { tokens } from "../src/theme";


export const mockDataTeam = [
  
  {
    id: 1,
    name: "Jon Snow",
    email: "jonsnow@gmail.com",
    gender: "male",
    phone: "(665)121-5454",
    membership:"Premium",
    access: "manager",
    status:"Active",
    image: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBESFRESEhUSGBIYGBgSHBgSGBUYGBgSGBgZGhgYGBgcIS4lHB4rHxgYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISHjQrJSQ0NDQxNjQ0NDY0NDQ0NDQ0NDQ0NDQ0NDE0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ/Mf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EADsQAAIBAgMGAwUHAgYDAAAAAAABAgMRBCExBRJBUWFxBiKBEzKRofBCUmKxwdHhM3IUI4KisvEVNEP/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAKREAAgEEAgIBAwQDAAAAAAAAAAECAxEhMQQSMlFBE4GhBSJhcUKxwf/aAAwDAQACEQMRAD8A1mgsOsFjc4hm6I4j2JYsBlgSH2CwA2wWHAANsIPEAG2EsPEsAMCwTmopttJc3kYuK8VYOm7Oe8/wJy+aKtpEpN6Nuwtjm340wmX9TP8AA8i7g/E2EqZKoovS00439XkR2XsnpL0bCQtghJNJpprms18RSSoBYBUAICQoqQAAOEQAWFsKhQBthbDrBYFhtgHWAAbYSw+wlgVGWEsPsJYAZYLDrCADbAOsIAIAthAAMjam3aVB7ivOrwpwzl3fCK6sg8R7XlTtQote2mr3+5D7z68jN2ZgI03xlOXmlOWcpPqzKrWUTpocd1Hd6MvaFDGYuX+Y2oaqEPdSfN/aZc2X4agveSul3sztsNhY2WSLtLDQtokcMq8menHjxisHHx8OU5OCSily5/Ep4/wrvZwikunHnxyPR8Js6F962fNliGASlJvR8ApvYcI6PNcLsPG4aKnh6l9296c/dfPJ6M1Nk7ehVbp1Y+yrrJwk8m+cHx7Hbzw65HMeJ/DMMTHfirVYK8Wsm7cL/NGlOvJO0jGtxYyV47LNgsY/hzaEqkHTqyvVhdZqzlBcX1XE2rHemmro8qUXF2Yg4LACASFAWwAJDrAKgWBIWwgqACwg8ABjQ2w4GgVG2EsOEAG2EHWEAEAUQAaVdpY2FCnUqzflir93wS6t2RbZxPjvEuU8PQXu51ZLm1lBP/cyJy6q5eEe0kijs3fqTlXq/wBSpLefJR0jFdErHWUMLZqRzuFj7vSx12AneOZ5lSTbue1SioqyLmHeSNCkinQgaFGBnY2bLtDIsorUyeEjSJjIWcCrVgXERV0JIReTzvxNhZYarGvT03t63Xin3zNvC1lUhCpHSUVL4lnxHh41Kc4vimc54PxDlTqU5a0punfo7SX5nVx5XwcXLp2/cb9hbCgdR54JCgLYFgSBAOQAWFAEgAAWwADLCDxrQKiMRig0ANEHAANEHCADWcD4naljVH7tOHzcjv2eeeJpbuPV9HCC/wCRnV8Wb8fzRbovNd7HQYfEU4NQnOKly5dzmacJykowe7zlyXTqWK2w6NvPVkpPPXNv8zg6r5PXUn8HaYbFwfuyi+zNfD1IvueTrCSoyXs68r3vaaav2Op2NtOo/LN3fMiSS0WUnLDO23ixTnFasxsVvqClHV5nL4z/ABc5NqcYU1zkItXIlHGD0T2kPvIZWOGwGHqS1xNN37N+judFRqVqe7GTU6emWq624kuzKxTRLtCmpQl0z/c43w1FRrY2K4yhUt3i0/nE67atbcp1Jcot/I4jwvO+JxPWEJX9ZfuacfyMeWrwOsABUd55QJAA4AEhQBIAEhwAAIAoADQBiMARiDmNBUGIKIwAEFEAEZw3jPDx/wAThakXFvOEkmrprzRuu1zujzjEy35uTzftZu9uHnWbMq0uqt7OrjU+0nL0XadOdrxWZXo7OqVHPfms/s3cbd3xOi2NTUklY6CGDhbRfA4O1j1VC6ODw3hqShKMqine6iorON3e7ee9bPXma/h7Z04ThCct5q7u8suFzosQowi7WSsU9gJznKpwflRDk5bLKmo6Orq0VKCh0OC2rsap7S85v2fCOa7ebgegTna3Kwk4wks7MNZwQnZZPOtlbCxcZP8Az17NveSe9KS8tt3zZON7O1jqdlYavHKe61zg3ursnoumdjXhgaeqhG/RFtU7Il3eyqajhGB4hVsNXfKEnl0Ob8L4WcXUqSg0pwp2fbfb/NHX7apqVKrHnCa/2sgrxqRw8Z0Wo2UJPJO8cnJFoT6O9itSl9Vdb2uQIAYqPSTurniyXVtP4BIcAAAKCFAAUQUAAAABrEFYgADWOGsFRAYAwBAAABrPNK1WKnCmnnCbv1cm1f5nphwHiPZ8Kc6rjGzTjUT6Np5+tznrrCZ28SW0dBsOdsjoXXUVd8DlNlTzViPHbY35ypw9yN03zkuHY42rs9WMkkW9rbR35xhe0X8GSeH9oxjOdOLvuvN2aSfR8V2ObxU51bbq+BPsrZlffTlKyyut5K/YdVYd23hHe1vEtGE4wqPdvkmoy3bvS87WT7slx2IbSnSu7cVo1yMTA7NrbzcrSjwi2mrdTcVWcYWlGyWSVupFibpfBNsnaqqLPXR9zZdVNHnuPxTpz9rBNfejzS4rqdJsraKqwjOLumrkqTWCkop5RPtmaUJ9mvjkOwkVFypebccI2T0T3Ve3wKO15bzpU/vzivS//ZrY2e4k1a9rXet3wRCjd4I7KKbZk1Eru3B2+GQiEFR6kVZWPDnLtJv2OAARJA4EIKAKKIKAAAAAwRiiMFQEYojAGsAYACAAAAZm29nRr06is9/ckota3tdLrmaYjDSasy0ZOLuji/D+JSlC+jS+JPtTZrpb06a3ruTtzTd0Z9aDoYipTySvvwv9yWaz9WvQ6COI9pDd+0ldHmzTjI9ulJTgjmNlYypXqSp7qhu8Ja2s3p6HX4HYNeTd5xVoxkt2PF3yu30MV0k5qW6r535q+tmbODxM4Xaq1VdbtnZpK2Vrq6tmQ2mbRjK2GjoKWxqu5C1Z3lzissr5mRt+ti8JSVWFqi4xs73vZLK+foaWGxlRqF60lblG98s7qxehTTUb3dtHPOXw0QwQ+y3Y5qFOtiacZ1Kfs7pOztvdbpaZF3YGEVClu9ZS9G27fM2Kqy6GTia+61e1rNrnoZ7ZDeCDFy9pXgk35FKpdc8kl8S/OpKdnJ3Zm7NW86lR/bdl/bHj8b/AvnoUacVFO2TyeRWk5OKeAHIah5ucwAgBACioBQBQAAAAcABEIKxAVARijWAIwAQAAAAAABADlvGmD8tKvFeaEt19YO7+Tz9WUMBi7OD62yOj8R/0kuc1+TOExMHSnFr3b3XR8v2OOsk5WPS4rahc7SeAc7zpvXkMngsXFJwSl31MHZe2pxdru1/tapHZYLbFNxWaz5nO4tHappok2ZhsS93filztzN+jRa1uZNHbEMldbzz/ANKJK+24qN7xTenMWDkW8dWjFP4djk8dJ1akKcV5pSt2is7vp+wYjbUm2rKU5XSUbtu97emWZqeH9myp71So71JavkuEURorsnhBRSjH3VkuyHIQVHqLR4sneTFQ4Yh5JAAAqAAVCCoAcAIAAAcABCxGDFBUBrBsQABBbiXAARg2NbAHXC5HvFXH7RpUIe0qyUY6c23ySWbYJSvop+Jp2hTjzk38F/JzuJpprS649i1jdqQxUoTpqSpxTS31Zu7zlbgskRuFzgrSvN2PW48etNJmRPAu+9C1/wAXDLgy7hqs4rOM3xenys+5ajReSt69CxToXy/MycjVRM+OKqKW8ozbtaztpbTsS0MLia7vbcjzyvnwSWR0GGwKST3b9uRqYbC9ra2IciyiVNi7HhTzzcvvS1fr+x09OFkRYakloW7FSX6MSSs2urEJcalGdrq8vMlz52I0erCSlFNHiVIOM2mA8Yh5YzEQ5CAmCwoqEFQAqFEQoAAAAEYjFGMFQYAIADEbG1qsILenKMVzk7HPY3xOotqlDe/FN2XolmZzqwhtmsKM56R0EmZWO29hqSe9NSa+zT8zv6ZL1OX2jtbEVk4zklB/ZgrLs3q/iYleFkc0uWm7RR1w4TteTNnafjOq0/YQjBXS3p+aWfTRfM5/G4ipWcp1JynPOzk9L8lovQKlHyX9QUcrruUlVb2zeNGMdI6bAQW7G2ll8LF+EChsCqpw3PtR+cTapQzMjdEUKZZpU9CzCgiWFGxBZFrCx00NSnTKGGVrGnSTZWxLZNTJ7q2dkhkFYkir6l0UbM3beHjKnKT96Hni1rdPTs9DEo4372nNamt4nxahBU1703d9Ir+bfM5mi3ZX+sjlnXnSqXi/7NFQjVhaSN6E1JXi010HmHCco6Oz42L9DGp5TyfNaevI9Chz4zxLD/B5tfgThmOV+S6KNi081oOO5O5wNWFQAhSSRRUNQqAFAAAIhoGJtfbipt06WdTRy4R6Lm/yKTnGEbyLU6cpy6xNTE4unTV6kkuS4vsjExniBtNU42/FKzfotDFlKU3vSblJ8XmyCdTclBPSWXrwPMq8yU3aOD1aXBhFXlkkrSlNuU5SlLnJ3IJwu0i5KA2EDh+o3lncqaWEVJwKGMjY2Zx1MvGw80VzkkXpyuys42QsaHlS6FSnRt5X6djelSyK0sMpLrzJjV3cOBSw8pU5KceB1OExsJxT4/qYEIZ7stfk1+313mhTlB3j6o0VSzyV6Ha4KSki06djn9h46Kkoydukv0Z1ip3SaNYyUtFGmtkVEvUCnCDRew6ZZEMmbG4jEwpQdSbyXDi3wSK+O2jSopuck5cIxavfryOV2ntKdd3eUVpFaLr/ACZVK0YrGy0Kbk/4Isbip1pynPjlbglwQ6mrEEF9dSxH1PNnJvLOyKsSDWh9xt9SqJEp15weTdjQobRg8pZPnwM6UvrMakdVHl1KWnj0c9bi06u1n2dBCSeaaa6DjAhKUX5W12L1DaD0nmua/VHqUf1CE8Sw/wAHlVv0+cMxyvyaQoyE1JJpproPO9O+UcDTWGKAgEkHObd2z7O9Km71Hk2vsJ8P7vyOaowazZRhUe/vO74vW93x6vM2opNKzT7HicitKTuz3ePRjBWQ2KM7bT3YwlylH80jUjGxl7dd4wjznH/kjnp+aOqfizXnDJBGBKlkhJowv8GpSqriZyW/WguWZp4lZFLZsd6pJm1N2TZlLLSNLERsMglYnxH6ENNOxktGj2EqKlk/+vUjVOcMmt6PPivhp6Zdi1C/xHp9vUsptEdblaMIy49eT9OZao4rEUsqc3blK5FOhF5rLnu2z7rRgqU1e0k13a/NMlTXwyOpd/8AOYpcIPtZfmiKW0sVUylPdjyTu/gsvzIVGppl9f6RFTk9ZZdL/wAL5Euo7ZZHVeiRJfabb1zzZJGV9NPr4jIU137/ALaFiGeeRk5ejRISCRYVstCtJ8PyLNLQoyRyauLYbKeZLEAhm39XCDvfIbiMlxI4TtmLAsPQKbuiKVTIMFPyyf4rD4Bcw1Z03+F6r9TYjJNJrR5mJYt4Cvuvcej06PkelwOV1fSbw9Hm87i9l3gsrZogAHtXR41meWbNV6sV6/C5Zp1tyc19neduSvw+JU2ZO1aPW6+RbqyUK8oyzjLL5Hgy3b+D6CPj9zSoTU1GS4mNtb+rRhzkvln+hZo1PYz3Je680+a/cjxsN7E4flaUsuit+pSEes7/ABZ/6Lyd4/dG7CORE2rsntZFZxVzl+ToKuNyRFsWDvJ9SXHZJ3H7Ej5bm17QZl/kWsUiGmlxJ8UsyGl2M46NHslgld/yOnEFF5EtRZEAgRIr2vmRKX7aE0FkGEI78/mCbzEaQ1N55kEj23bgSUllwIo3srj4triQwFRrIt0HkUJO7WXLgXoLIMBUea15ElN5cSGb0JaTQYCtHIp3kk8tTRmrog3PK9CEwZ9aq1F9r+pNgJXhfnL9CljbrsTbNfka/F+jNLftK3yasJD0iCnLRFlsz0y3wT/4qQEW+gNfr1PZl9CHpHnF3GcJdTQ26rqnWj62KlWGRfw/+bRnB6rNHW3Zp+jFLaFxSVbDqas5xzXdcPgQ7Iq+1nGX3YOPq3/BX2Fibb9KXbMl8L03er/e18CZR6xkvWvuE7yX8/8ADo6smkrfMr03clxE0svq5BDU4UsHUyHHWUX2J9jwtBFXac1uvndK3qaWBhaC6IvLECi8huJ5qw2gsv4HTeo2l9aELRZ7JNB7eWgNc7/IbvZcbFSSFPPgWIW6fMrNq5bgrrgSwiKsuiIm89LDqis7XI089WEiGTxWSJMtbfMjjL6zH2yKssQPUu0pWsU1qWYpol6IJnmrWQ6HMijLoSwtxIJJbj6KyaIlIkpZFWDG2pT9/LRXF2Y/JL0JdqQzvzyK+zHlNfWqNVmJR+Rp4fVt2JYPed+TsVpysracWTYBO3rczaLk26AAUsScLU0LOxNZdmKB6L8Wca8jHw3/ALEvX8zY8Nf/AF/vl+bAC9bwf9IrT81/bNatq/rgV/tsUDiidTKW1NI9zcw/u/6QAtPwRC8mV58QpcAAj4LFl8BktH9cAAoSV4lqOiACWEVq/vIYveYAWWipPH6+I6WnoKBQsNWqLEdEABhC0tSdcO36gBDJHQ49yRfsAFWCjtTgUdlaz7fqgA0j4lH5FvElzZ/u+oAVeixIAAUJP//Z"
  },
  {
    id: 2,
    name: "Cersei Lannister",
    email: "cerseilannister@gmail.com",
    gender: "male",
    membership:"Free",
    phone: "(421)314-2288",
    access: "manager",
    status:"Active",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRywvQPeuxf1zt5TdhvXqp4Kz0eAKZhm6WxqQ&usqp=CAU"
  },
  {
    id: 3,
    name: "Jaime Lannister",
    email: "jaimelannister@gmail.com",
    gender: "male",
    membership:"Premium",
    phone: "(422)982-6739",
    access: "user",
    status:"Active",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAL_r36T9dtShfXHnNKnsR-UJK6BIgNEGu0Q&usqp=CAU"
  },
  {
    id: 4,
    name: "Anya Stark",
    email: "anyastark@gmail.com",
    gender: "female",
    membership:"Premium",
    phone: "(921)425-6742",
    access: "admin",
    image: "https://www.herbertsmithfreehills.com/.imaging/mte/hsf-corporate-site-theme/person-profile/dam/feed/contact/laurence-vincent_WEB.jpg0/jcr:content/laurence-vincent_WEB.jpg"
  },
  {
    id: 5,
    name: "Daenerys Targaryen",
    email: "daenerystargaryen@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(421)445-1189",
    access: "user",
    status:"Active",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqetD3yAzuEPOTwFFDGax4i22QMvg4piOhgA&usqp=CAU"
  },
  {
    id: 6,
    name: "Ever Melisandre",
    email: "evermelisandre@gmail.com",
    gender: "male",
    membership:"Free",
    phone: "(232)545-6483",
    access: "manager",
    status:"Active",
    image: "https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },
  {
    id: 7,
    name: "Ferrara Clifford",
    email: "ferraraclifford@gmail.com",
    gender: "female",
    membership:"Premium",
    phone: "(543)124-0123",
    access: "user",
    status:"Active",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2t-r7v3uF3IXpChgaqnC7s8g4XMSRt0XN-g&usqp=CAU"
  },
  {
    id: 8,
    name: "Rossini Frances",
    email: "rossinifrances@gmail.com",
    gender: "male",
    membership:"Free",
    phone: "(222)444-5555",
    access: "user",
    status:"Active",
    image: "https://assets.entrepreneur.com/content/3x2/2000/1683123836-GettyImages-1090697048.jpg"
  },
  {
    id: 9,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Active",
    image:"https://learn.microsoft.com/en-us/training/media/career-paths/example-person.png"
  },
  {
    id: 10,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqetD3yAzuEPOTwFFDGax4i22QMvg4piOhgA&usqp=CAU"
  },
  {
    id: 11,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://assets.entrepreneur.com/content/3x2/2000/1683123836-GettyImages-1090697048.jpg"
  },{
    id: 12,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },{
    id: 13,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRywvQPeuxf1zt5TdhvXqp4Kz0eAKZhm6WxqQ&usqp=CAU"
  },{
    id: 14,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },
];

export const mockdataPremium = [
  {
    id: 10,
    name: "Jon Snow",
    email: "jonsnow@gmail.com",
    gender: "male",
    phone: "(665)121-5454",
    membership:"Premium",
    access: "admin",
    status:"Active",
    image: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBESFRESEhUSGBIYGBgSHBgSGBUYGBgSGBgZGhgYGBgcIS4lHB4rHxgYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISHjQrJSQ0NDQxNjQ0NDY0NDQ0NDQ0NDQ0NDQ0NDE0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ/Mf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EADsQAAIBAgMGAwUHAgYDAAAAAAABAgMRBCExBRJBUWFxBiKBEzKRofBCUmKxwdHhM3IUI4KisvEVNEP/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAKREAAgEEAgIBAwQDAAAAAAAAAAECAxEhMQQSMlFBE4GhBSJhcUKxwf/aAAwDAQACEQMRAD8A1mgsOsFjc4hm6I4j2JYsBlgSH2CwA2wWHAANsIPEAG2EsPEsAMCwTmopttJc3kYuK8VYOm7Oe8/wJy+aKtpEpN6Nuwtjm340wmX9TP8AA8i7g/E2EqZKoovS00439XkR2XsnpL0bCQtghJNJpprms18RSSoBYBUAICQoqQAAOEQAWFsKhQBthbDrBYFhtgHWAAbYSw+wlgVGWEsPsJYAZYLDrCADbAOsIAIAthAAMjam3aVB7ivOrwpwzl3fCK6sg8R7XlTtQote2mr3+5D7z68jN2ZgI03xlOXmlOWcpPqzKrWUTpocd1Hd6MvaFDGYuX+Y2oaqEPdSfN/aZc2X4agveSul3sztsNhY2WSLtLDQtokcMq8menHjxisHHx8OU5OCSily5/Ep4/wrvZwikunHnxyPR8Js6F962fNliGASlJvR8ApvYcI6PNcLsPG4aKnh6l9296c/dfPJ6M1Nk7ehVbp1Y+yrrJwk8m+cHx7Hbzw65HMeJ/DMMTHfirVYK8Wsm7cL/NGlOvJO0jGtxYyV47LNgsY/hzaEqkHTqyvVhdZqzlBcX1XE2rHemmro8qUXF2Yg4LACASFAWwAJDrAKgWBIWwgqACwg8ABjQ2w4GgVG2EsOEAG2EHWEAEAUQAaVdpY2FCnUqzflir93wS6t2RbZxPjvEuU8PQXu51ZLm1lBP/cyJy6q5eEe0kijs3fqTlXq/wBSpLefJR0jFdErHWUMLZqRzuFj7vSx12AneOZ5lSTbue1SioqyLmHeSNCkinQgaFGBnY2bLtDIsorUyeEjSJjIWcCrVgXERV0JIReTzvxNhZYarGvT03t63Xin3zNvC1lUhCpHSUVL4lnxHh41Kc4vimc54PxDlTqU5a0punfo7SX5nVx5XwcXLp2/cb9hbCgdR54JCgLYFgSBAOQAWFAEgAAWwADLCDxrQKiMRig0ANEHAANEHCADWcD4naljVH7tOHzcjv2eeeJpbuPV9HCC/wCRnV8Wb8fzRbovNd7HQYfEU4NQnOKly5dzmacJykowe7zlyXTqWK2w6NvPVkpPPXNv8zg6r5PXUn8HaYbFwfuyi+zNfD1IvueTrCSoyXs68r3vaaav2Op2NtOo/LN3fMiSS0WUnLDO23ixTnFasxsVvqClHV5nL4z/ABc5NqcYU1zkItXIlHGD0T2kPvIZWOGwGHqS1xNN37N+judFRqVqe7GTU6emWq624kuzKxTRLtCmpQl0z/c43w1FRrY2K4yhUt3i0/nE67atbcp1Jcot/I4jwvO+JxPWEJX9ZfuacfyMeWrwOsABUd55QJAA4AEhQBIAEhwAAIAoADQBiMARiDmNBUGIKIwAEFEAEZw3jPDx/wAThakXFvOEkmrprzRuu1zujzjEy35uTzftZu9uHnWbMq0uqt7OrjU+0nL0XadOdrxWZXo7OqVHPfms/s3cbd3xOi2NTUklY6CGDhbRfA4O1j1VC6ODw3hqShKMqine6iorON3e7ee9bPXma/h7Z04ThCct5q7u8suFzosQowi7WSsU9gJznKpwflRDk5bLKmo6Orq0VKCh0OC2rsap7S85v2fCOa7ebgegTna3Kwk4wks7MNZwQnZZPOtlbCxcZP8Az17NveSe9KS8tt3zZON7O1jqdlYavHKe61zg3ursnoumdjXhgaeqhG/RFtU7Il3eyqajhGB4hVsNXfKEnl0Ob8L4WcXUqSg0pwp2fbfb/NHX7apqVKrHnCa/2sgrxqRw8Z0Wo2UJPJO8cnJFoT6O9itSl9Vdb2uQIAYqPSTurniyXVtP4BIcAAAKCFAAUQUAAAABrEFYgADWOGsFRAYAwBAAABrPNK1WKnCmnnCbv1cm1f5nphwHiPZ8Kc6rjGzTjUT6Np5+tznrrCZ28SW0dBsOdsjoXXUVd8DlNlTzViPHbY35ypw9yN03zkuHY42rs9WMkkW9rbR35xhe0X8GSeH9oxjOdOLvuvN2aSfR8V2ObxU51bbq+BPsrZlffTlKyyut5K/YdVYd23hHe1vEtGE4wqPdvkmoy3bvS87WT7slx2IbSnSu7cVo1yMTA7NrbzcrSjwi2mrdTcVWcYWlGyWSVupFibpfBNsnaqqLPXR9zZdVNHnuPxTpz9rBNfejzS4rqdJsraKqwjOLumrkqTWCkop5RPtmaUJ9mvjkOwkVFypebccI2T0T3Ve3wKO15bzpU/vzivS//ZrY2e4k1a9rXet3wRCjd4I7KKbZk1Eru3B2+GQiEFR6kVZWPDnLtJv2OAARJA4EIKAKKIKAAAAAwRiiMFQEYojAGsAYACAAAAZm29nRr06is9/ckota3tdLrmaYjDSasy0ZOLuji/D+JSlC+jS+JPtTZrpb06a3ruTtzTd0Z9aDoYipTySvvwv9yWaz9WvQ6COI9pDd+0ldHmzTjI9ulJTgjmNlYypXqSp7qhu8Ja2s3p6HX4HYNeTd5xVoxkt2PF3yu30MV0k5qW6r535q+tmbODxM4Xaq1VdbtnZpK2Vrq6tmQ2mbRjK2GjoKWxqu5C1Z3lzissr5mRt+ti8JSVWFqi4xs73vZLK+foaWGxlRqF60lblG98s7qxehTTUb3dtHPOXw0QwQ+y3Y5qFOtiacZ1Kfs7pOztvdbpaZF3YGEVClu9ZS9G27fM2Kqy6GTia+61e1rNrnoZ7ZDeCDFy9pXgk35FKpdc8kl8S/OpKdnJ3Zm7NW86lR/bdl/bHj8b/AvnoUacVFO2TyeRWk5OKeAHIah5ucwAgBACioBQBQAAAAcABEIKxAVARijWAIwAQAAAAAABADlvGmD8tKvFeaEt19YO7+Tz9WUMBi7OD62yOj8R/0kuc1+TOExMHSnFr3b3XR8v2OOsk5WPS4rahc7SeAc7zpvXkMngsXFJwSl31MHZe2pxdru1/tapHZYLbFNxWaz5nO4tHappok2ZhsS93filztzN+jRa1uZNHbEMldbzz/ANKJK+24qN7xTenMWDkW8dWjFP4djk8dJ1akKcV5pSt2is7vp+wYjbUm2rKU5XSUbtu97emWZqeH9myp71So71JavkuEURorsnhBRSjH3VkuyHIQVHqLR4sneTFQ4Yh5JAAAqAAVCCoAcAIAAAcABCxGDFBUBrBsQABBbiXAARg2NbAHXC5HvFXH7RpUIe0qyUY6c23ySWbYJSvop+Jp2hTjzk38F/JzuJpprS649i1jdqQxUoTpqSpxTS31Zu7zlbgskRuFzgrSvN2PW48etNJmRPAu+9C1/wAXDLgy7hqs4rOM3xenys+5ajReSt69CxToXy/MycjVRM+OKqKW8ozbtaztpbTsS0MLia7vbcjzyvnwSWR0GGwKST3b9uRqYbC9ra2IciyiVNi7HhTzzcvvS1fr+x09OFkRYakloW7FSX6MSSs2urEJcalGdrq8vMlz52I0erCSlFNHiVIOM2mA8Yh5YzEQ5CAmCwoqEFQAqFEQoAAAAEYjFGMFQYAIADEbG1qsILenKMVzk7HPY3xOotqlDe/FN2XolmZzqwhtmsKM56R0EmZWO29hqSe9NSa+zT8zv6ZL1OX2jtbEVk4zklB/ZgrLs3q/iYleFkc0uWm7RR1w4TteTNnafjOq0/YQjBXS3p+aWfTRfM5/G4ipWcp1JynPOzk9L8lovQKlHyX9QUcrruUlVb2zeNGMdI6bAQW7G2ll8LF+EChsCqpw3PtR+cTapQzMjdEUKZZpU9CzCgiWFGxBZFrCx00NSnTKGGVrGnSTZWxLZNTJ7q2dkhkFYkir6l0UbM3beHjKnKT96Hni1rdPTs9DEo4372nNamt4nxahBU1703d9Ir+bfM5mi3ZX+sjlnXnSqXi/7NFQjVhaSN6E1JXi010HmHCco6Oz42L9DGp5TyfNaevI9Chz4zxLD/B5tfgThmOV+S6KNi081oOO5O5wNWFQAhSSRRUNQqAFAAAIhoGJtfbipt06WdTRy4R6Lm/yKTnGEbyLU6cpy6xNTE4unTV6kkuS4vsjExniBtNU42/FKzfotDFlKU3vSblJ8XmyCdTclBPSWXrwPMq8yU3aOD1aXBhFXlkkrSlNuU5SlLnJ3IJwu0i5KA2EDh+o3lncqaWEVJwKGMjY2Zx1MvGw80VzkkXpyuys42QsaHlS6FSnRt5X6djelSyK0sMpLrzJjV3cOBSw8pU5KceB1OExsJxT4/qYEIZ7stfk1+313mhTlB3j6o0VSzyV6Ha4KSki06djn9h46Kkoydukv0Z1ip3SaNYyUtFGmtkVEvUCnCDRew6ZZEMmbG4jEwpQdSbyXDi3wSK+O2jSopuck5cIxavfryOV2ntKdd3eUVpFaLr/ACZVK0YrGy0Kbk/4Isbip1pynPjlbglwQ6mrEEF9dSxH1PNnJvLOyKsSDWh9xt9SqJEp15weTdjQobRg8pZPnwM6UvrMakdVHl1KWnj0c9bi06u1n2dBCSeaaa6DjAhKUX5W12L1DaD0nmua/VHqUf1CE8Sw/wAHlVv0+cMxyvyaQoyE1JJpproPO9O+UcDTWGKAgEkHObd2z7O9Km71Hk2vsJ8P7vyOaowazZRhUe/vO74vW93x6vM2opNKzT7HicitKTuz3ePRjBWQ2KM7bT3YwlylH80jUjGxl7dd4wjznH/kjnp+aOqfizXnDJBGBKlkhJowv8GpSqriZyW/WguWZp4lZFLZsd6pJm1N2TZlLLSNLERsMglYnxH6ENNOxktGj2EqKlk/+vUjVOcMmt6PPivhp6Zdi1C/xHp9vUsptEdblaMIy49eT9OZao4rEUsqc3blK5FOhF5rLnu2z7rRgqU1e0k13a/NMlTXwyOpd/8AOYpcIPtZfmiKW0sVUylPdjyTu/gsvzIVGppl9f6RFTk9ZZdL/wAL5Euo7ZZHVeiRJfabb1zzZJGV9NPr4jIU137/ALaFiGeeRk5ejRISCRYVstCtJ8PyLNLQoyRyauLYbKeZLEAhm39XCDvfIbiMlxI4TtmLAsPQKbuiKVTIMFPyyf4rD4Bcw1Z03+F6r9TYjJNJrR5mJYt4Cvuvcej06PkelwOV1fSbw9Hm87i9l3gsrZogAHtXR41meWbNV6sV6/C5Zp1tyc19neduSvw+JU2ZO1aPW6+RbqyUK8oyzjLL5Hgy3b+D6CPj9zSoTU1GS4mNtb+rRhzkvln+hZo1PYz3Je680+a/cjxsN7E4flaUsuit+pSEes7/ABZ/6Lyd4/dG7CORE2rsntZFZxVzl+ToKuNyRFsWDvJ9SXHZJ3H7Ej5bm17QZl/kWsUiGmlxJ8UsyGl2M46NHslgld/yOnEFF5EtRZEAgRIr2vmRKX7aE0FkGEI78/mCbzEaQ1N55kEj23bgSUllwIo3srj4triQwFRrIt0HkUJO7WXLgXoLIMBUea15ElN5cSGb0JaTQYCtHIp3kk8tTRmrog3PK9CEwZ9aq1F9r+pNgJXhfnL9CljbrsTbNfka/F+jNLftK3yasJD0iCnLRFlsz0y3wT/4qQEW+gNfr1PZl9CHpHnF3GcJdTQ26rqnWj62KlWGRfw/+bRnB6rNHW3Zp+jFLaFxSVbDqas5xzXdcPgQ7Iq+1nGX3YOPq3/BX2Fibb9KXbMl8L03er/e18CZR6xkvWvuE7yX8/8ADo6smkrfMr03clxE0svq5BDU4UsHUyHHWUX2J9jwtBFXac1uvndK3qaWBhaC6IvLECi8huJ5qw2gsv4HTeo2l9aELRZ7JNB7eWgNc7/IbvZcbFSSFPPgWIW6fMrNq5bgrrgSwiKsuiIm89LDqis7XI089WEiGTxWSJMtbfMjjL6zH2yKssQPUu0pWsU1qWYpol6IJnmrWQ6HMijLoSwtxIJJbj6KyaIlIkpZFWDG2pT9/LRXF2Y/JL0JdqQzvzyK+zHlNfWqNVmJR+Rp4fVt2JYPed+TsVpysracWTYBO3rczaLk26AAUsScLU0LOxNZdmKB6L8Wca8jHw3/ALEvX8zY8Nf/AF/vl+bAC9bwf9IrT81/bNatq/rgV/tsUDiidTKW1NI9zcw/u/6QAtPwRC8mV58QpcAAj4LFl8BktH9cAAoSV4lqOiACWEVq/vIYveYAWWipPH6+I6WnoKBQsNWqLEdEABhC0tSdcO36gBDJHQ49yRfsAFWCjtTgUdlaz7fqgA0j4lH5FvElzZ/u+oAVeixIAAUJP//Z"
  },
  {
    id: 7,
    name: "Ferrara Clifford",
    email: "ferraraclifford@gmail.com",
    gender: "female",
    membership:"Premium",
    phone: "(543)124-0123",
    access: "user",
    status:"Active",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2t-r7v3uF3IXpChgaqnC7s8g4XMSRt0XN-g&usqp=CAU"
  },
  {
    id: 11,
    name: "Jaime Lannister",
    email: "jaimelannister@gmail.com",
    gender: "male",
    membership:"Premium",
    phone: "(422)982-6739",
    access: "user",
    status:"Active",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAL_r36T9dtShfXHnNKnsR-UJK6BIgNEGu0Q&usqp=CAU"
  },
  {
    id: 4,
    name: "Anya Stark",
    email: "anyastark@gmail.com",
    gender: "female",
    membership:"Premium",
    phone: "(921)425-6742",
    access: "admin",
    status:"Active",
    image: "https://www.herbertsmithfreehills.com/.imaging/mte/hsf-corporate-site-theme/person-profile/dam/feed/contact/laurence-vincent_WEB.jpg0/jcr:content/laurence-vincent_WEB.jpg"
  },
  {
    id: 1,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqetD3yAzuEPOTwFFDGax4i22QMvg4piOhgA&usqp=CAU"
  },
  {
    id: 3,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://assets.entrepreneur.com/content/3x2/2000/1683123836-GettyImages-1090697048.jpg"
  },{
    id: 12,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },

]

export const mockdataFree =[
  {
    id: 2,
    name: "Cersei Lannister",
    email: "cerseilannister@gmail.com",
    gender: "male",
    membership:"Free",
    phone: "(421)314-2288",
    access: "manager",
    status:"Active",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRywvQPeuxf1zt5TdhvXqp4Kz0eAKZhm6WxqQ&usqp=CAU"
  },
  {
    id: 5,
    name: "Daenerys Targaryen",
    email: "daenerystargaryen@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(421)445-1189",
    access: "user",
    status:"Active",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqetD3yAzuEPOTwFFDGax4i22QMvg4piOhgA&usqp=CAU"
  },
  {
    id: 6,
    name: "Ever Melisandre",
    email: "evermelisandre@gmail.com",
    gender: "male",
    membership:"Free",
    phone: "(232)545-6483",
    access: "manager",
    status:"Active",
    image: "https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },
  {
    id: 8,
    name: "Rossini Frances",
    email: "rossinifrances@gmail.com",
    gender: "male",
    membership:"Free",
    phone: "(222)444-5555",
    access: "user",
    status:"Active",
    image: "https://assets.entrepreneur.com/content/3x2/2000/1683123836-GettyImages-1090697048.jpg"
  },
  {
    id: 9,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Active",
    image:"https://learn.microsoft.com/en-us/training/media/career-paths/example-person.png"
  },
  {
    id: 10,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqetD3yAzuEPOTwFFDGax4i22QMvg4piOhgA&usqp=CAU"
  },
  {
    id: 11,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://assets.entrepreneur.com/content/3x2/2000/1683123836-GettyImages-1090697048.jpg"
  },{
    id: 12,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },{
    id: 13,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRywvQPeuxf1zt5TdhvXqp4Kz0eAKZhm6WxqQ&usqp=CAU"
  },{
    id: 14,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },
]
export const mockDataBlocked = [
  {
    id: 10,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqetD3yAzuEPOTwFFDGax4i22QMvg4piOhgA&usqp=CAU"
  },
  {
    id: 11,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://assets.entrepreneur.com/content/3x2/2000/1683123836-GettyImages-1090697048.jpg"
  },{
    id: 12,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },{
    id: 13,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRywvQPeuxf1zt5TdhvXqp4Kz0eAKZhm6WxqQ&usqp=CAU"
  },{
    id: 14,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    gender: "female",
    membership:"Free",
    phone: "(444)555-6239",
    access: "admin",
    status:"Blocked",
    image:"https://qph.cf2.quoracdn.net/main-qimg-5b502372ba7299709e874bebf0f6d26c-pjlq"
  },

]

export const mockDataContacts = [
  {
    id: 1,
    name: "Jon Snow",
    email: "jonsnow@gmail.com",
    age: 35,
    date: "2021-09-01",
    cost: "43.95",
    phone: "(665)121-5454",
    address: "0912 Won Street, Alabama, SY 10001",
    city: "New York",
    zipCode: "10001",
    registrarId: 123512,
  },
  {
    id: 2,
    name: "Cersei Lannister",
    email: "cerseilannister@gmail.com",
    age: 42,
    date: "2022-04-01",
    cost: "133.45",
    phone: "(421)314-2288",
    address: "1234 Main Street, New York, NY 10001",
    city: "New York",
    zipCode: "13151",
    registrarId: 123512,
  },
  {
    id: 3,
    name: "Jaime Lannister",
    email: "jaimelannister@gmail.com",
    age: 45,
    date: "2021-09-01",
    cost: "43.95",
    phone: "(422)982-6739",
    address: "3333 Want Blvd, Estanza, NAY 42125",
    city: "New York",
    zipCode: "87281",
    registrarId: 4132513,
  },
  {
    id: 4,
    name: "Anya Stark",
    email: "anyastark@gmail.com",
    age: 16,
    date: "2022-11-05",
    cost: "200.95",
    phone: "(921)425-6742",
    address: "1514 Main Street, New York, NY 22298",
    city: "New York",
    zipCode: "15551",
    registrarId: 123512,
  },
  {
    id: 5,
    name: "Daenerys Targaryen",
    email: "daenerystargaryen@gmail.com",
    age: 31,
    date: "2022-11-02",
    cost: "13.55",
    phone: "(421)445-1189",
    address: "11122 Welping Ave, Tenting, CD 21321",
    city: "Tenting",
    zipCode: "14215",
    registrarId: 123512,
  },
  {
    id: 6,
    name: "Ever Melisandre",
    email: "evermelisandre@gmail.com",
    age: 150,
    date: "2021-09-01",
    cost: "43.95",
    phone: "(232)545-6483",
    address: "1234 Canvile Street, Esvazark, NY 10001",
    city: "Esvazark",
    zipCode: "10001",
    registrarId: 123512,
  },
  {
    id: 7,
    name: "Ferrara Clifford",
    email: "ferraraclifford@gmail.com",
    age: 44,
    date: "2019-04-15",
    cost: "24.20",
    phone: "(543)124-0123",
    address: "22215 Super Street, Everting, ZO 515234",
    city: "Evertin",
    zipCode: "51523",
    registrarId: 123512,
  },
  {
    id: 8,
    name: "Rossini Frances",
    email: "rossinifrances@gmail.com",
    age: 36,
    date: "2022-04-01",
    cost: "133.45",
    phone: "(222)444-5555",
    address: "4123 Ever Blvd, Wentington, AD 142213",
    city: "Esteras",
    zipCode: "44215",
    registrarId: 512315,
  },
  {
    id: 9,
    name: "Harvey Roxie",
    email: "harveyroxie@gmail.com",
    age: 65,
    date: "2021-09-01",
    cost: "43.95",
    phone: "(444)555-6239",
    address: "51234 Avery Street, Cantory, ND 212412",
    city: "Colunza",
    zipCode: "111234",
    registrarId: 928397,
  },
  {
    id: 10,
    name: "Enteri Redack",
    email: "enteriredack@gmail.com",
    age: 42,
    date: "2019-04-15",
    cost: "24.20",
    phone: "(222)444-5555",
    address: "4123 Easer Blvd, Wentington, AD 142213",
    city: "Esteras",
    zipCode: "44215",
    registrarId: 533215,
  },
  {
    id: 11,
    name: "Steve Goodman",
    email: "stevegoodmane@gmail.com",
    age: 11,
    date: "2022-11-02",
    cost: "13.55",
    phone: "(444)555-6239",
    address: "51234 Fiveton Street, CunFory, ND 212412",
    city: "Colunza",
    zipCode: "1234",
    registrarId: 92197,
  },
];

export const mockDataInvoices = [
  {
    id: 1,
    name: "Jon Snow",
    email: "jonsnow@gmail.com",
    cost: "21.24",
    phone: "(665)121-5454",
    date: "03/12/2022",
  },
  {
    id: 2,
    name: "Cersei Lannister",
    email: "cerseilannister@gmail.com",
    cost: "1.24",
    phone: "(421)314-2288",
    date: "06/15/2021",
  },
  {
    id: 3,
    name: "Jaime Lannister",
    email: "jaimelannister@gmail.com",
    cost: "11.24",
    phone: "(422)982-6739",
    date: "05/02/2022",
  },
  {
    id: 4,
    name: "Anya Stark",
    email: "anyastark@gmail.com",
    cost: "80.55",
    phone: "(921)425-6742",
    date: "03/21/2022",
  },
  {
    id: 5,
    name: "Daenerys Targaryen",
    email: "daenerystargaryen@gmail.com",
    cost: "1.24",
    phone: "(421)445-1189",
    date: "01/12/2021",
  },
  {
    id: 6,
    name: "Ever Melisandre",
    email: "evermelisandre@gmail.com",
    cost: "63.12",
    phone: "(232)545-6483",
    date: "11/02/2022",
  },
  {
    id: 7,
    name: "Ferrara Clifford",
    email: "ferraraclifford@gmail.com",
    cost: "52.42",
    phone: "(543)124-0123",
    date: "02/11/2022",
  },
  {
    id: 8,
    name: "Rossini Frances",
    email: "rossinifrances@gmail.com",
    cost: "21.24",
    phone: "(222)444-5555",
    date: "05/02/2021",
  },
];



export const mockBarData = [
  {
    country: "AD",
    "male": 137,
    "male dogColor": "hsl(229, 70%, 50%)",
    female: 96,
    femaleColor: "hsl(296, 70%, 50%)",
    Transgender: 140,
    TransgenderColor: "hsl(340, 70%, 50%)",
  },
  {
    country: "AE",
    "male": 55,
    "male Color": "hsl(307, 70%, 50%)",
    female: 28,
    burgerColor: "hsl(111, 70%, 50%)",
    Transgender: 58,
    TransgenderColor: "hsl(273, 70%, 50%)",
    Nonbinary: 29,
    nonbinaryColor: "hsl(275, 70%, 50%)",
  },
  {
    country: "AF",
    "male": 109,
    "maleColor": "hsl(72, 70%, 50%)",
    female: 23,
    femaleColor: "hsl(96, 70%, 50%)",
    Transgender: 34,
    TransgenderColor: "hsl(106, 70%, 50%)",
    Nonbinary: 152,
    NonbinaryColor: "hsl(256, 70%, 50%)",
  },
  {
    country: "AG",
    "male": 133,
    "maleColor": "hsl(257, 70%, 50%)",
    female: 52,
    femaleColor: "hsl(326, 70%, 50%)",
    Transgender: 43,
    TransgenderColor: "hsl(110, 70%, 50%)",
    Nonbinary: 83,
    NonColor: "hsl(9, 70%, 50%)",
  },
  {
    country: "AI",
    "male": 81,
    "maleColor": "hsl(190, 70%, 50%)",
    female: 80,
    femaleColor: "hsl(325, 70%, 50%)",
   Transgender: 112,
   TransgenderColor: "hsl(54, 70%, 50%)",
    Nonbinary: 35,
    NonbinaryColor: "hsl(285, 70%, 50%)",
  },
  {
    country: "AL",
    "male": 66,
    "maleColor": "hsl(208, 70%, 50%)",
    female: 111,
    femaleColor: "hsl(334, 70%, 50%)",
    Transgender: 167,
    TransgenderColor: "hsl(182, 70%, 50%)",
    Nonbinary: 18,
    NonbinaryColor: "hsl(76, 70%, 50%)",
  },
  {
    country: "AM",
    "male": 80,
    "maleColor": "hsl(87, 70%, 50%)",
    female: 47,
   femaleColor: "hsl(141, 70%, 50%)",
    Transgender: 158,
    TransgenderColor: "hsl(224, 70%, 50%)",
    Nonbinary: 49,
    NonbinaryColor: "hsl(274, 70%, 50%)",
  },
];

export const mockPieData = [
  {
    id: "hack",
    label: "hack",
    value: 239,
    color: "hsl(104, 70%, 50%)",
  },
  {
    id: "make",
    label: "make",
    value: 170,
    color: "hsl(162, 70%, 50%)",
  },
  {
    id: "go",
    label: "go",
    value: 322,
    color: "hsl(291, 70%, 50%)",
  },
  {
    id: "lisp",
    label: "lisp",
    value: 503,
    color: "hsl(229, 70%, 50%)",
  },
  {
    id: "scala",
    label: "scala",
    value: 584,
    color: "hsl(344, 70%, 50%)",
  },
];

export const mockLineData = [
  {
    id: "India",
    color: tokens("dark").greenAccent[400],
    data: [
      {
        x: "male",
        y: 12,
      },
      {
        x: "female",
        y: 75,
      },
      {
        x: "Transgender",
        y: 36,
      },
      {
        x: "non-binary",
        y: 216,
      },
      
    ],
  },
  {
    id: "france",
    color: tokens("dark").blueAccent[300],
    data: [
      {
        x: "male",
        y: 8,
      },
      {
        x: "female",
        y: 4,
      },
      {
        x: "Transgender",
        y: 45,
      },
      {
        x: "non-binary",
        y: 0,
      },
    ],
  },
  {
    id: "us",
    color: tokens("dark").redAccent[200],
    data: [
      {
        x: "male",
        y: 19,
      },
      {
        x: "female",
        y: 156,
      },
      {
        x: "Transgender",
        y: 51,
      },
      {
        x: "non-binary",
        y: 190,
      },
    ],
  },
];

export const mockGeographyData = [
  {
    id: "AFG",
    value: 520600,
  },
  {
    id: "AGO",
    value: 949905,
  },
  {
    id: "ALB",
    value: 329910,
  },
  {
    id: "ARE",
    value: 675484,
  },
  {
    id: "ARG",
    value: 432239,
  },
  {
    id: "ARM",
    value: 288305,
  },
  {
    id: "ATA",
    value: 415648,
  },
  {
    id: "ATF",
    value: 665159,
  },
  {
    id: "AUT",
    value: 798526,
  },
  {
    id: "AZE",
    value: 481678,
  },
  {
    id: "BDI",
    value: 496457,
  },
  {
    id: "BEL",
    value: 252276,
  },
  {
    id: "BEN",
    value: 440315,
  },
  {
    id: "BFA",
    value: 343752,
  },
  {
    id: "BGD",
    value: 920203,
  },
  {
    id: "BGR",
    value: 261196,
  },
  {
    id: "BHS",
    value: 421551,
  },
  {
    id: "BIH",
    value: 974745,
  },
  {
    id: "BLR",
    value: 349288,
  },
  {
    id: "BLZ",
    value: 305983,
  },
  {
    id: "BOL",
    value: 430840,
  },
  {
    id: "BRN",
    value: 345666,
  },
  {
    id: "BTN",
    value: 649678,
  },
  {
    id: "BWA",
    value: 319392,
  },
  {
    id: "CAF",
    value: 722549,
  },
  {
    id: "CAN",
    value: 332843,
  },
  {
    id: "CHE",
    value: 122159,
  },
  {
    id: "CHL",
    value: 811736,
  },
  {
    id: "CHN",
    value: 593604,
  },
  {
    id: "CIV",
    value: 143219,
  },
  {
    id: "CMR",
    value: 630627,
  },
  {
    id: "COG",
    value: 498556,
  },
  {
    id: "COL",
    value: 660527,
  },
  {
    id: "CRI",
    value: 60262,
  },
  {
    id: "CUB",
    value: 177870,
  },
  {
    id: "-99",
    value: 463208,
  },
  {
    id: "CYP",
    value: 945909,
  },
  {
    id: "CZE",
    value: 500109,
  },
  {
    id: "DEU",
    value: 63345,
  },
  {
    id: "DJI",
    value: 634523,
  },
  {
    id: "DNK",
    value: 731068,
  },
  {
    id: "DOM",
    value: 262538,
  },
  {
    id: "DZA",
    value: 760695,
  },
  {
    id: "ECU",
    value: 301263,
  },
  {
    id: "EGY",
    value: 148475,
  },
  {
    id: "ERI",
    value: 939504,
  },
  {
    id: "ESP",
    value: 706050,
  },
  {
    id: "EST",
    value: 977015,
  },
  {
    id: "ETH",
    value: 461734,
  },
  {
    id: "FIN",
    value: 22800,
  },
  {
    id: "FJI",
    value: 18985,
  },
  {
    id: "FLK",
    value: 64986,
  },
  {
    id: "FRA",
    value: 447457,
  },
  {
    id: "GAB",
    value: 669675,
  },
  {
    id: "GBR",
    value: 757120,
  },
  {
    id: "GEO",
    value: 158702,
  },
  {
    id: "GHA",
    value: 893180,
  },
  {
    id: "GIN",
    value: 877288,
  },
  {
    id: "GMB",
    value: 724530,
  },
  {
    id: "GNB",
    value: 387753,
  },
  {
    id: "GNQ",
    value: 706118,
  },
  {
    id: "GRC",
    value: 377796,
  },
  {
    id: "GTM",
    value: 66890,
  },
  {
    id: "GUY",
    value: 719300,
  },
  {
    id: "HND",
    value: 739590,
  },
  {
    id: "HRV",
    value: 929467,
  },
  {
    id: "HTI",
    value: 538961,
  },
  {
    id: "HUN",
    value: 146095,
  },
  {
    id: "IDN",
    value: 490681,
  },
  {
    id: "IND",
    value: 549818,
  },
  {
    id: "IRL",
    value: 630163,
  },
  {
    id: "IRN",
    value: 596921,
  },
  {
    id: "IRQ",
    value: 767023,
  },
  {
    id: "ISL",
    value: 478682,
  },
  {
    id: "ISR",
    value: 963688,
  },
  {
    id: "ITA",
    value: 393089,
  },
  {
    id: "JAM",
    value: 83173,
  },
  {
    id: "JOR",
    value: 52005,
  },
  {
    id: "JPN",
    value: 199174,
  },
  {
    id: "KAZ",
    value: 181424,
  },
  {
    id: "KEN",
    value: 60946,
  },
  {
    id: "KGZ",
    value: 432478,
  },
  {
    id: "KHM",
    value: 254461,
  },
  {
    id: "OSA",
    value: 942447,
  },
  {
    id: "KWT",
    value: 414413,
  },
  {
    id: "LAO",
    value: 448339,
  },
  {
    id: "LBN",
    value: 620090,
  },
  {
    id: "LBR",
    value: 435950,
  },
  {
    id: "LBY",
    value: 75091,
  },
  {
    id: "LKA",
    value: 595124,
  },
  {
    id: "LSO",
    value: 483524,
  },
  {
    id: "LTU",
    value: 867357,
  },
  {
    id: "LUX",
    value: 689172,
  },
  {
    id: "LVA",
    value: 742980,
  },
  {
    id: "MAR",
    value: 236538,
  },
  {
    id: "MDA",
    value: 926836,
  },
  {
    id: "MDG",
    value: 840840,
  },
  {
    id: "MEX",
    value: 353910,
  },
  {
    id: "MKD",
    value: 505842,
  },
  {
    id: "MLI",
    value: 286082,
  },
  {
    id: "MMR",
    value: 915544,
  },
  {
    id: "MNE",
    value: 609500,
  },
  {
    id: "MNG",
    value: 410428,
  },
  {
    id: "MOZ",
    value: 32868,
  },
  {
    id: "MRT",
    value: 375671,
  },
  {
    id: "MWI",
    value: 591935,
  },
  {
    id: "MYS",
    value: 991644,
  },
  {
    id: "NAM",
    value: 701897,
  },
  {
    id: "NCL",
    value: 144098,
  },
  {
    id: "NER",
    value: 312944,
  },
  {
    id: "NGA",
    value: 862877,
  },
  {
    id: "NIC",
    value: 90831,
  },
  {
    id: "NLD",
    value: 281879,
  },
  {
    id: "NOR",
    value: 224537,
  },
  {
    id: "NPL",
    value: 322331,
  },
  {
    id: "NZL",
    value: 86615,
  },
  {
    id: "OMN",
    value: 707881,
  },
  {
    id: "PAK",
    value: 158577,
  },
  {
    id: "PAN",
    value: 738579,
  },
  {
    id: "PER",
    value: 248751,
  },
  {
    id: "PHL",
    value: 557292,
  },
  {
    id: "PNG",
    value: 516874,
  },
  {
    id: "POL",
    value: 682137,
  },
  {
    id: "PRI",
    value: 957399,
  },
  {
    id: "PRT",
    value: 846430,
  },
  {
    id: "PRY",
    value: 720555,
  },
  {
    id: "QAT",
    value: 478726,
  },
  {
    id: "ROU",
    value: 259318,
  },
  {
    id: "RUS",
    value: 268735,
  },
  {
    id: "RWA",
    value: 136781,
  },
  {
    id: "ESH",
    value: 151957,
  },
  {
    id: "SAU",
    value: 111821,
  },
  {
    id: "SDN",
    value: 927112,
  },
  {
    id: "SDS",
    value: 966473,
  },
  {
    id: "SEN",
    value: 158085,
  },
  {
    id: "SLB",
    value: 178389,
  },
  {
    id: "SLE",
    value: 528433,
  },
  {
    id: "SLV",
    value: 353467,
  },
  {
    id: "ABV",
    value: 251,
  },
  {
    id: "SOM",
    value: 445243,
  },
  {
    id: "SRB",
    value: 202402,
  },
  {
    id: "SUR",
    value: 972121,
  },
  {
    id: "SVK",
    value: 319923,
  },
  {
    id: "SVN",
    value: 728766,
  },
  {
    id: "SWZ",
    value: 379669,
  },
  {
    id: "SYR",
    value: 16221,
  },
  {
    id: "TCD",
    value: 101273,
  },
  {
    id: "TGO",
    value: 498411,
  },
  {
    id: "THA",
    value: 506906,
  },
  {
    id: "TJK",
    value: 613093,
  },
  {
    id: "TKM",
    value: 327016,
  },
  {
    id: "TLS",
    value: 607972,
  },
  {
    id: "TTO",
    value: 936365,
  },
  {
    id: "TUN",
    value: 898416,
  },
  {
    id: "TUR",
    value: 237783,
  },
  {
    id: "TWN",
    value: 878213,
  },
  {
    id: "TZA",
    value: 442174,
  },
  {
    id: "UGA",
    value: 720710,
  },
  {
    id: "UKR",
    value: 74172,
  },
  {
    id: "URY",
    value: 753177,
  },
  {
    id: "USA",
    value: 658725,
  },
  {
    id: "UZB",
    value: 550313,
  },
  {
    id: "VEN",
    value: 707492,
  },
  {
    id: "VNM",
    value: 538907,
  },
  {
    id: "VUT",
    value: 650646,
  },
  {
    id: "PSE",
    value: 476078,
  },
  {
    id: "YEM",
    value: 957751,
  },
  {
    id: "ZAF",
    value: 836949,
  },
  {
    id: "ZMB",
    value: 714503,
  },
  {
    id: "ZWE",
    value: 405217,
  },
  {
    id: "KOR",
    value: 171135,
  },
];
