import React, {useEffect, useState} from "react";
import axios from "axios";

export default function Users() {
  const [userData, setUserData] = useState([]);
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get("http://localhost:5000/singleuser");

        setUserData(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  return (
    <React.Fragment>
      <div className="relative flex flex-col w-full h-full overflow-scroll text-gray-70  shadow-md rounded-xl bg-clip-border">
        <table className="w-full text-left table-auto min-w-max">
          <thead>
            <tr>
            <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                  id
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                  Name
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                  email
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                  Phone Number
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                Address
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                Date Of Birth
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                Sub Cast
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                Blood Group
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70">
                Marital Status
                </p>
              </th>
              <th className="p-4 border-b border-blue-gray-100 bg-blue-gray-50">
                <p className="block font-sans text-sm antialiased font-normal leading-none text-blue-gray-900 opacity-70"></p>
              </th>
            </tr>
          </thead>
          <tbody>
            {userData.map((uData, index) => 
              <tr key={uData.email}>
                <td className="p-2 border-b border-blue-gray-50">{index + 1}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.fullname}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.email}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.phnumber}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.address}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.date}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.subcast}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.bloodgroup}</td>
                <td className="p-2 border-b border-blue-gray-50">{uData.maritalstatus}</td>
                
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {/* </div> */}
    </React.Fragment>
  );
}
