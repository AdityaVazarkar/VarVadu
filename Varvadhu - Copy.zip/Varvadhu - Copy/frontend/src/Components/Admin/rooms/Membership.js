import React, { useState } from 'react';
import { Avatar, Box, Typography } from '@mui/material';
import { DataGrid, gridClasses } from '@mui/x-data-grid';
import { grey } from '@mui/material/colors';

const Membership = () => {
  const [pageSize, setPageSize] = useState(5);

  const columns = [
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'email', headerName: 'Email', flex: 1 },
    { field: 'photo', headerName: 'Photo', flex: 1, renderCell: (params) => <Avatar src={params.value} /> },
  ];

  // Example rows data (replace with your actual data)
  const rows = [
    { id: 1, name: 'Pranav', email: 'pranav@gmail.com', photo: '' },
    { id: 2, name: 'Aditya ', email: 'aditya@gmail.com', photo: '' },
    { id: 3, name: 'Sachin ', email: 'sachin@gmail.com', photo: '' },
    // Add more rows as needed
  ];

  return (
    <Box
      sx={{
        height: 400,
        width: '100%',
      }}
    >
      <Typography
        variant="h3"
        component="h3"
        sx={{ textAlign: 'center', mt: 3, mb: 3 }}
      >
        Manage Membership
      </Typography>
      <DataGrid
        columns={columns}
        rows={rows}
        rowsPerPageOptions={[5, 10, 20]}
        pageSize={pageSize}
        onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
        getRowSpacing={(params) => ({
          top: params.isFirstVisible ? 0 : 5,
          bottom: params.isLastVisible ? 0 : 5,
        })}
        sx={{
          [`& .${gridClasses.row}`]: {
            bgcolor: (theme) =>
              theme.palette.mode === 'light' ? grey[200] : grey[900],
          },
        }}
      />
    </Box>
  );
};

export default Membership;
