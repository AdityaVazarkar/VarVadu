import React, { createContext, useContext } from 'react';
import PropTypes from 'prop-types';
const DefaultValue = {
  state: {
    customElements: [],
    users: [],
  },
  dispatch: () => {},
};

const Context = createContext(DefaultValue);

export const useValue = () => useContext(Context);

const ContextProvider = ({ children }) => {
  return <Context.Provider value={DefaultValue}>{children}</Context.Provider>;
};

ContextProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

export default ContextProvider;
