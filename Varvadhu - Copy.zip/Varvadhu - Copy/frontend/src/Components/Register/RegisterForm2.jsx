import {
  Button,
  FormControl,
  FormGroup,
  FormLabel,
  Grid,
  Input,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import axios from "axios";
import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import MenuItem from "@mui/material/MenuItem";
import {  useNavigate } from "react-router-dom";
import { Label } from "@mui/icons-material";

const useStyle = makeStyles({
  formStyle: {
    width: "50%",
    margin: "auto",
    padding: 20,
    border: "1px solid black",
    paddingTop: 20,
    boxShadow: "0px 0px 8px rgba(0,0,0,0.5)",
  },
});

const Father = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Yes",
    label: "Yes",
  },
  {
    value: "No",
    label: "No",
  },
];

const Brother = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "0",
    label: "0",
  },
  {
    value: "1",
    label: "1",
  },
  {
    value: "2",
    label: "2",
  },
  {
    value: "3",
    label: "3",
  },
  {
    value: "4",
    label: "4",
  },
  {
    value: "5",
    label: "5",
  },
  {
    value: "6",
    label: "6",
  },
  {
    value: "7",
    label: "7",
  },
  {
    value: "8",
    label: "8",
  },
];

const RegisterForm2 = () => {
  const classes = useStyle();
  const navigate = useNavigate();

  // const [value, setValue] = useState({
  //   father: "",
  //   mother:"",
  //   brother: "",
  //   sister: "",
  //   married_brother: "",
  //   married_sister: "",
  //   fathername:"",
  //   mothername:"",
  //   fatheroccupation:"",
  //   motheroccupation:"",
  //   first_photo: "",
  //   second_photo: "",
   
  // });

  // const handleInput = (event) => {
  //   setValue((prev) => ({
  //     ...prev,
  //     [event.target.name]: [event.target.value],
  //   }));
  // };

  // const handleSubmit = (event) => {
  //   event.preventDefault();
  //   axios
  //     .post("http://localhost:5000/enroll2", value)
  //     .then((res) => {
  //       alert("Data Submited");
  //       navigate("/");
  //       console.log(res);
  //     })
  //     .catch((err) => console.log(err));
  // };

  // Define state using useState
  const [values, setValues] = useState({
    father: "",
    mother: "",
    brother: "",
    sister: "",
    married_brother: "",
    married_sister: "",
    fathername: "",
    mothername: "",
    fatheroccupation: "",
    motheroccupation: "",
    first_photo: null,
    second_photo: null,
    email: "",
  });

  // Handle input changes
  const handleInput = (event) => {
    const { name, value } = event.target;
    // Handle file inputs separately
    if (name === "first_photo" || name === "second_photo") {
      setValues((prev) => ({
        ...prev,
        [name]: event.target.files[0],
      }));
    } else {
      // For other inputs, update the state normally
      setValues((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  // Handle form submission
  const handleSubmit = async (event) => {
    event.preventDefault();
    // FormData object to handle file uploads
    const formData = new FormData();
    // Append all form values to formData
    Object.entries(values).forEach(([key, value]) => {
      formData.append(key, value);
    });

    try {
      // Send POST request with formData
      const res = await axios.post("http://localhost:5000/enroll2", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("Data Submitted");
      navigate("/");
      console.log(res);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
   <form
        className={classes.form}
        onSubmit={handleSubmit}
      >
        <div>
   
          <FormGroup className={classes.formStyle}>
            <FormControl>
              <FormLabel className="mt-3">
                Educational / Professional Details :
              </FormLabel>
            </FormControl>

            <TextField
                  id="outlined-select-currency"
                  type="email"
                  label="Email"
                  name="email"
                  required
                  onChange={handleInput}
                  sx={{ margin:2 ,width:300}}
                >
                
                </TextField>
            <Grid container>
              <Grid item xs={6}>
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Father :"
                  defaultValue="Select"
                  name="father"
                  required
                  onChange={handleInput}
                  sx={{ margin:2 ,width:150}}
                >
                  {Father.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  label="Number of Brother :"
                  name="brother"
                  required
                  onChange={handleInput}
                  defaultValue="Select"
                  sx={{ margin:2 ,width:150}}
                >
                  {Brother.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  label="Number of Sister :"
                  required
                  name="sister"
                  onChange={handleInput}
                  defaultValue="Select"
                  sx={{ margin:2 ,width:150}}
                >
                  {Brother.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <FormControl>
                  <InputLabel>Father Full name</InputLabel>
                  <Input name="fathername"  onChange={handleInput} required/>
                </FormControl>
                <FormControl sx={{marginTop: 2}}>
                  <InputLabel >Mother Full name</InputLabel>
                  <Input name="mothername"  onChange={handleInput} required/>
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  id="outlined-select-currency"
                  select
                  label=" Mother :"
                  name="mother"
                  required
                  defaultValue="Select"
                  onChange={handleInput}
                  sx={{ margin:2 ,width:150}}
                >
                  {Father.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  label="Married Brother :"
                  name="married_brother"
                  defaultValue="Select"
                  onChange={handleInput}
                  required
                  sx={{ margin:2 ,width:150}}
                >
                  {Brother.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  required
                  label="Married Sister :"
                  name="married_sister"
                  defaultValue="Select"
                  onChange={handleInput}
                  sx={{ margin:2 ,width:150}}
                >
                  {Brother.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <FormControl>
                  <InputLabel>Parent Occupation Father</InputLabel>
                  <Input name="fatheroccupation" onChange={handleInput} required />
                </FormControl>  
                
                <FormControl sx={{marginTop: 2}}>
                  <InputLabel>Parent Occupation Mother</InputLabel>
                  <Input name="motheroccupation" onChange={handleInput} required/>
                </FormControl>
              </Grid>
            </Grid>

            <FormControl >
              <FormLabel className="mt-3">Profile Photos :</FormLabel>
            </FormControl>

            <Grid container sx={{marginTop:2}}>
              <Grid item xs={6}>
                <FormControl>
                  <Typography variant="p">Upload your first profile picture </Typography>
                  <Input type="file" name="first_photo" onChange={handleInput} />
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <FormControl>
                  <Typography variant="p">Upload your Second profile picture </Typography>
                  <Input type="file" name="second_photo" onChange={handleInput} />
                </FormControl>
              </Grid>
            </Grid>
            <br />
            <Button type="submit" variant="contained" color="primary">
              Submit
            </Button>
          </FormGroup>
      
        </div>
      </form>
    </div>
  );
};

export default RegisterForm2;
