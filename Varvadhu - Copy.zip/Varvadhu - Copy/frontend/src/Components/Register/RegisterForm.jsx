import React, { useState } from "react";
import {
  FormControl,
  FormGroup,
  FormLabel,
  Grid,
  Input,
  InputLabel,
  Button,
  TextField
} from "@mui/material";
import axios from "axios";
import { makeStyles } from "@mui/styles";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";

import {  useNavigate } from "react-router-dom";
const useStyle = makeStyles({
  formStyle: {
    width: "50%",
    margin: "auto",
    padding: 20,
    border: "1px solid black",
    paddingTop: 20,
    boxShadow: "0px 0px 8px rgba(0,0,0,0.5)",
  },
});

const SubCast = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Maratha",
    label: "Maratha",
  },
  {
    value: "Hindu",
    label: "Hindu",
  },
  {
    value: "96 Kuli",
    label: "96 Kuli",
  },
  {
    value: "Kunbi",
    label: "Kunbi",
  },
];

const BloodGroup = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "A+",
    label: "A+",
  },
  {
    value: "A-",
    label: "A-",
  },
  {
    value: "B+",
    label: "B+",
  },
  {
    value: "B-",
    label: "B+",
  },
  {
    value: "O+",
    label: "O-",
  },
  {
    value: "AB+",
    label: "AB+",
  },
  {
    value: "AB-",
    label: "AB-",
  },
  {
    value: "Don't Konw",
    label: "Don't Konw",
  },
];

const MaritialStatus = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Unmarried Boy",
    label: "Unmarried Boy",
  },
  {
    value: "Unmarried Girl",
    label: "Unmarried Girl",
  },
  {
    value: "Divorcee Boy / Widower",
    label: "Divorcee Boy / Widower",
  },
  {
    value: "Divorcee Girl / Widow",
    label: "Divorcee Girl / Widow",
  },
];

const Diet = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Non Vegetarian",
    label: "Non Vegetarian",
  },
  {
    value: "Vegetarian",
    label: "Vegetarian",
  },
  {
    value: "N/A",
    label: "N/A",
  },
];

const Lens = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "No",
    label: "No",
  },
  {
    value: "Yes",
    label: "Yes",
  },
];
const Gender = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "male",
    label: "Male",
  },
  {
    value: "female",
    label: "female",
  },
];

const Color = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "FAIR",
    label: "FAIR",
  },
  {
    value: "GORA",
    label: "GORA",
  },
  {
    value: "SAWALA",
    label: "SAWALA",
  },
  {
    value: "GAVHAL",
    label: "GAVHAL",
  },
  {
    value: "NIMGORA",
    label: "NIMGORA",
  },
  {
    value: "BLACK",
    label: "BLACK",
  },
];

const Height = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "3ft",
    label: "3ft",
  },
  {
    value: "3.5ft",
    label: "3.5ft",
  },
  {
    value: "4ft",
    label: "4ft",
  },
  {
    value: "4.5ft",
    label: "4.5ft",
  },
  {
    value: "5ft",
    label: "5ft",
  },
  {
    value: "5.5ft",
    label: "5.5ft",
  },
  {
    value: "6ft",
    label: "6ft",
  },
  {
    value: "6.5ft",
    label: "6.5ft",
  },
  {
    value: "7ft",
    label: "7ft",
  },
];

function RegisterForm() {
  const classes = useStyle();
  const navigate = useNavigate();
  const [value, setValue] = useState({
    fullname: "",
    email: "",
    phnumber: "",
    address: "",
    pin: "",
    complexion: "",
    date: "",
    height: "",
    pydisability: "",
    subcast: "",
    bloodgroup: "",
    maritalstatus: "",
    diet: "",
    lens: "",
    spectacle: "",
    disability: "",
    gender:""
  });

  const handleInput = (event) => {
    setValue((prev) => ({
      ...prev,
      [event.target.name]: [event.target.value],
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .post("http://localhost:5000/enroll", value)
      .then((res) => {
        alert("Data Submited ");
        navigate("/form1");
        console.log(res);
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      {/* <h1>Enroll Form</h1> */}
      <form
        className={classes.form}
        onSubmit={handleSubmit}
      >
        <FormGroup className={classes.formStyle}>
          <FormControl className="pb-3">
            <FormLabel>Personal Details :</FormLabel>
          </FormControl>
          <Grid container>
            <Grid item xs={6}>
              
              <TextField
                name="fullname"
                label="fullname"
                value={value.fullname}
                onChange={handleInput}
                fullWidth
                margin="normal"
                required
              />
             
              <TextField
                name="email"
                label="email"
                value={value.email}
                onChange={handleInput}
                fullWidth
                margin="normal"
                required
              />
            
              <TextField
                name="phnumber"
                label="phnumber"
                value={value.phnumber}
                onChange={handleInput}
                fullWidth
                margin="normal"
                required
              />
             
              <TextField
                name="address"
                label="address"
                value={value.address}
                onChange={handleInput}
                fullWidth
                margin="normal"
                required
              />
             
              <TextField
                name="pin"
                label="pin"
                value={value.pin}
                onChange={handleInput}
                fullWidth
                margin="normal"
                required
              />
              <Box sx={{ display: "grid" }}>
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Complexion "
                  name="complexion"
                  defaultValue="Select"
                  onChange={handleInput}
                  sx={{ marginTop: 2, width: 100 }}
                >
                  {Color.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
                {/* <form className={classes.container} noValidate> */}
                <TextField
                  id="date"
                  label="Birthday"
                  type="date"
                  name="date"
                  defaultValue="0000-00-00"
                  onChange={handleInput}
                  className={classes.textField}
                  required
                  sx={{ marginTop: 2, width: 150 }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
                {/* </form> */}
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Height"
                  name="height"
                  defaultValue="Select"
                  onChange={handleInput}
                  required
                  sx={{ marginTop: 2 }}
                >
                  {Height.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Physical Disablities"
                  name="pydisability"
                  defaultValue="Select"
                  onChange={handleInput}
                  required
                  sx={{ marginTop: 2, width: 150 }}
                >
                  {Lens.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
            </Grid>
            <Grid item xs={6} sx={{ display: "grid" }}>
              <TextField
                id="outlined-select-currency"
                select
                label="Sub Cast"
                name="subcast"
                onChange={handleInput}
                defaultValue="Select"
                required
                sx={{ margin: 2 }}
              >
                {SubCast.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>

              <TextField
                id="outlined-select-currency"
                select
                label="Blood Group"
                name="bloodgroup"
                onChange={handleInput}
                defaultValue="Select"
                required
                sx={{ margin: 2, width: 100 }}
              >
                {BloodGroup.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                id="outlined-select-currency"
                select
                label="Maritial Status "
                name="maritalstatus"
                onChange={handleInput}
                required
                defaultValue="Select"
                sx={{ margin: 2 }}
              >
                {MaritialStatus.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                id="outlined-select-currency"
                select
                label="Diet "
                name="diet"
                onChange={handleInput}
                required
                defaultValue="Select"
                sx={{ margin: 2 }}
              >
                {Diet.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                id="outlined-select-currency"
                select
                label="Lens "
                name="lens"
                defaultValue="Select"
                required
                sx={{ margin: 2 }}
                onChange={handleInput}
              >
                {Lens.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                id="outlined-select-currency"
                select
                label="Spectacles"
                name="spectacle"
                defaultValue="Select"
                sx={{ margin: 2 }}
                required
                onChange={handleInput}
              >
                {Lens.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <br />
              <br />
              <TextField
                id="outlined-select-currency"
                select
                label="Gender"
                name="gender"
                defaultValue="Select"
                sx={{ margin: 2 }}
                required
                onChange={handleInput}
              >
                {Gender.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <br />
              <br />
              <FormControl>
                <InputLabel>If Yes, Please Specify</InputLabel>
                <Input name="disability" onChange={handleInput} />
              </FormControl>
            </Grid>
            {/* <Box sx={{ display: "block", margin: "auto", marginTop: 5 }}> */}

            {/* </Box> */}
          </Grid>
          <br />
          <Button type="submit" variant="contained" color="primary">
            Submit
          </Button>
        </FormGroup>
      </form>
    </div>
  );
}

export default RegisterForm;
