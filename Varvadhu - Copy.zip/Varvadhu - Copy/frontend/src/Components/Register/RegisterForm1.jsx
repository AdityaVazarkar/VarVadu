import {
  Button,
  FormControl,
  FormGroup,
  FormLabel,
  Grid,
  Input,
  InputLabel,
} from "@mui/material";
import axios from "axios";
import { makeStyles } from "@mui/styles";
import { TextField } from "@mui/material";
import MenuItem from "@mui/material/MenuItem";
import React, { useState } from "react";
import {  useNavigate } from "react-router-dom";
const useStyle = makeStyles({
  formStyle: {
    width: "50%",
    margin: "auto",
    padding: 20,
    border: "1px solid black",
    paddingTop: 20,
    boxShadow: "0px 0px 8px rgba(0,0,0,0.5)",
  },
});

const Rashi = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Unspecified",
    label: "Unspecified",
  },
  {
    value: "Mesh",
    label: "Mesh",
  },
  {
    value: "Vrushabh",
    label: "Vrushabh",
  },
  {
    value: "Mithun",
    label: "Mithun",
  },
  {
    value: "Kark",
    label: "Kark",
  },
  {
    value: "Sinha",
    label: "Sinha",
  },
  {
    value: "Kanya",
    label: "Kanya",
  },
  {
    value: "Tula",
    label: "Tula",
  },
  {
    value: "Vrischik",
    label: "Vrischik",
  },
  {
    value: "Dhanu",
    label: "Dhanu",
  },
  {
    value: "Makar",
    label: "Makar",
  },
  {
    value: "Kumbh",
    label: "Kumbh",
  },
  {
    value: "Meen",
    label: "Meen",
  },
];

const Nakshatra = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Unspecified",
    label: "Unspecified",
  },
  {
    value: "Ashwini",
    label: "Ashwini",
  },
  {
    value: "Ardra",
    label: "Ardra",
  },
  {
    value: "Aslesha",
    label: "Aslesha",
  },
  {
    value: "Anuradha",
    label: "Anuradha",
  },
  {
    value: "Bharani",
    label: "Bharani",
  },
  {
    value: "Chitra",
    label: "Chitra",
  },
  {
    value: "Dhanishta",
    label: "Dhanishta",
  },
  {
    value: "Hasta",
    label: "Hasta",
  },
];

const Charan = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Unspecified",
    label: "Unspecified",
  },
  {
    value: "1",
    label: "1",
  },
  {
    value: "2",
    label: "2",
  },
  {
    value: "3",
    label: "3",
  },
  {
    value: "4",
    label: "4",
  },
];

const Nadi = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Unspecified",
    label: "Unspecified",
  },
  {
    value: "Adhya",
    label: "Adhya",
  },
  {
    value: "Madhya",
    label: "Madhya",
  },
  {
    value: "Antya",
    label: "Antya",
  },
];

const Gan = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Unspecified",
    label: "Unspecified",
  },
  {
    value: "Dev Gan",
    label: "Dev Gan",
  },
  {
    value: "Manushya Gan",
    label: "Manushya Gan",
  },
  {
    value: "Rakshas Gan",
    label: "Rakshas Gan",
  },
];

const Mangal = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "Yes",
    label: "Yes",
  },
  {
    value: "No",
    label: "No",
  },

  {
    value: "Sanmya",
    label: "Sanmya",
  },
  {
    value: "Nirdosh",
    label: "Nirdosh",
  },
  {
    value: "Not Konwn",
    label: "Not Konwn",
  },
];

const Education = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "12th to Graduate",
    label: "12th to Graduate",
  },
  {
    value: "Post-Graduate",
    label: "Post-Graduate",
  },
  {
    value: "Doctor",
    label: "Doctor",
  },
  {
    value: "Engineer / PG Engg",
    label: "Engineer / PG Engg",
  },
];

const Occupation = [
  {
    value: "Select",
    label: "Select",
  },
 
  {
    value: "Pursuing Education",
    label: "Pursuing Education",
  },
  {
    value: "Private Service",
    label: "Private Service",
  },
  {
    value: "Own Business ",
    label: "Own Business ",
  },
  {
    value: " Own Practice",
    label: " Own Practice",
  },
  {
    value: "Government Service",
    label: "Government Service",
  },
];

const Income = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "20000-30000",
    label: "20000-30000",
  },
  {
    value: "30000-40000",
    label: "30000-40000",
  },
  {
    value: "40000-50000",
    label: "40000-50000",
  },
  {
    value: "50000-60000",
    label: "50000-60000",
  },
  {
    value: "60000-70000",
    label: "60000-70000",
  },
  {
    value: "70000-80000",
    label: "70000-80000",
  },
  {
    value: "80000-90000",
    label: "80000-90000",
  },
  {
    value: "90000-100000",
    label: "90000-100000",
  },
  {
    value: "More than 100000",
    label: "More than 100000",
  },
];

const RegisterForm1 = () => {
  const classes = useStyle();
  const navigate = useNavigate();
  const [value, setValue] = useState({
    rashi: "",
    nakshatra: "",
    charan: "",
    nadi: "",
    gan: "",
    mangal: "",
    educationarea: "",
    education: "",
    occupationtype: "",
    occupationdetails: "",
    income: "",
    workingcity: "",
    ifmore: "",
    pan: "",
    residence: "",
    email1: "",
    email2: "",
    mobile1:"",
    mobile2:"",
    phone1:"",
    phone2:""
  });

  const handleInput = (event) => {
    setValue((prev) => ({
      ...prev,
      [event.target.name]: [event.target.value],
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .post("http://localhost:5000/enroll1", value)
      .then((res) => {
        alert("Data Submited ");
        navigate("/form2");
        console.log(res);
      })
      .catch((err) => console.log(err));
  };
  return (
    <div>
      <div>
        <form
          className={classes.form}
          onSubmit={handleSubmit}
        >
          <FormGroup className={classes.formStyle}>
            <FormControl>
              <FormLabel>Horoscope Details :</FormLabel>
            </FormControl>
            <Grid container>
              <Grid item xs={6}>
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Rashi "
                  sx={{ margin : 2}}
                  name="rashi"
                  defaultValue="Select"
                  onChange={handleInput}
                  required
                >
                  {Rashi.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  label="Charan"
                  name="charan"
                  onChange={handleInput}
                  defaultValue="Select"
                  sx={{ margin: 2 }}
                  required
                >
                  {Charan.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  label="Gan"
                  name="gan"
                  onChange={handleInput}
                  defaultValue="Select"
                  sx={{ margin: 2 }}
                  required
                >
                  {Gan.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Nakshara"
                  name="nakshatra"
                  onChange={handleInput}
                  defaultValue="Select"
                  sx={{ margin: 2 }}
                  required
                >
                  {Nakshatra.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  label="Nadi"
                  name="nadi"
                  onChange={handleInput}
                  defaultValue="Select"
                  required
                  sx={{ margin:2}}
                >
                  {Nadi.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Mangal "
                  defaultValue="Select"
                  name="mangal"
                  onChange={handleInput}
                  required
                  sx={{ margin:2.4 , width: 150}}
                >
                  {Mangal.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
            </Grid>

            <hr></hr>

            <FormControl>
              <FormLabel className="mt-3"> 
                Educational / Professional Details :
              </FormLabel>
            </FormControl>
            <Grid container>
              <Grid Grid item xs={6}>
                <TextField
                  id="outlined-select-currency"
                  select
                  label="Education Area :"
                  defaultValue="Select"
                  name="educationarea"
                  onChange={handleInput}
                  sx={{ margin: 2,width:'auto' }}
                  required
                >
                  {Education.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  id="outlined-select-currency"
                  select
                  label="Occupation Type:"
                  name="occupationtype"
                  onChange={handleInput}
                  defaultValue="Select"
                  sx={{ margin: 2 , width:'auto'}}
                  required
                >
                  {Occupation.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
                <TextField
                  id="outlined-select-currency"
                  required
                  select
                  label="Income:"
                  name="income"
                  onChange={handleInput}
                  defaultValue="Select"
                  sx={{ margin:2}}
                >
                  {Income.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid Grid item xs={6}>
                <FormControl>
                  <InputLabel>Education</InputLabel>
                  <Input name="education" onChange={handleInput} required />
                </FormControl>
                <FormControl sx={{marginTop:1}}>
                  <InputLabel>Occupation Details</InputLabel>
                  <Input name="occupationdetails" onChange={handleInput} required  />
                </FormControl>
                <FormControl>
                  <InputLabel sx={{marginTop:1}}>
                    Working in City
                  </InputLabel>
                  <Input name="workingcity" onChange={handleInput}  />
                </FormControl>
                <FormControl>
                  <InputLabel sx={{marginTop:1}}>
                    If more 100000 write her
                  </InputLabel>
                  <Input  name="ifmore" onChange={handleInput}  />
                </FormControl>
              </Grid>
            </Grid>
            <hr></hr>

            <FormControl className="mt-3 pb-3">
              <FormLabel>Address :</FormLabel>
            </FormControl>
            <Grid container>
              <Grid item xs={6}>
                <FormControl sx={{marginTop:1}}>
                  <InputLabel>
                    PAN/ Adhar/ Driving License :
                  </InputLabel>
                  <Input  name="pan" onChange={handleInput}  required />
                </FormControl>

                <FormControl sx={{marginTop:1}}>
                  <InputLabel>E-mail ID I :</InputLabel>
                  <Input  name="email1" onChange={handleInput}  required/>
                </FormControl>

                <FormControl sx={{marginTop:1}}>
                  <InputLabel>Mobile I :</InputLabel>
                  <Input name="mobile1" onChange={handleInput} required />
                </FormControl>

                <FormControl sx={{marginTop:1}}>
                  <InputLabel>Phone I:</InputLabel>
                  <Input name="phone1" onChange={handleInput}  required/>
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <FormControl sx={{marginTop:1}}>
                  <InputLabel>Residence Address With City :</InputLabel>
                  <Input name="residence" onChange={handleInput}  required/>
                </FormControl>

                <FormControl sx={{marginTop:1}}>
                  <InputLabel>E-mail II :</InputLabel>
                  <Input  name="email2" onChange={handleInput}  />
                </FormControl>

                <FormControl sx={{marginTop:1}}>
                  <InputLabel>Mobile II :</InputLabel>
                  <Input name="mobile2" onChange={handleInput}  />
                </FormControl>

                <FormControl sx={{marginTop:1}}>
                  <InputLabel>Phone II :</InputLabel>
                  <Input name="phone2" onChange={handleInput}  />
                </FormControl>
              </Grid>
            </Grid>

            <Button type="submit" variant="contained" color="primary">
              Submit
            </Button>
          </FormGroup>
        </form>
      </div>
    </div>
  );
};

export default RegisterForm1;
